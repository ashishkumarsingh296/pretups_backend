From Log Server


##############  SMSR  log rotation ########
05 03 * * * /pretupshome/pretups_scripts/rotateSMSRlogs.sh


############   Web LOGS ROTATION  ########
15 01 * * * /pretupshome/pretups_scripts/rotateWEBlogs.sh

bash-3.00$ cat /pretupshome/pretups_scripts/rotateSMSRlogs.sh
#/sbin/sh
#declare -i mon
#declare -i day1
##############################################################################
#        Bharti Telesoft Ltd.   Dated : 20/04/2008                           #
#####DATE funcition ##########################################################
mon=`date +%m`
day1=`date +%d`
day=`expr $day1 - 1`
#echo $mon
yr1=`date +%Y`
#echo $yr1
dir1="Log-"$day$mon$yr1
#echo $dir1


################################## Transaction Server One #######################################
#### SMSR Logs
cd /logs/translogs/trans1logs/pretups_smsrlogs
mkdir $dir1
cd /pretupsvar_trans1/pretups_smsrlogs/oldlogs
find *.log.* -mtime 0 -exec cp -r {} /logs/translogs/trans1logs/pretups_smsrlogs/$dir1 \;
cd /logs/translogs/trans1logs/pretups_smsrlogs/$dir1
gzip *
cd /logs/translogs/trans1logs/pretups_smsrlogs
find Log* -ctime +10 -exec rm -rf {} \;


#### SMSP Logs
cd /logs/translogs/trans1logs/pretups_smsplogs
mkdir $dir1
cd /pretupsvar_trans1/pretups_smsplogs/oldlogs
find *.log.* -mtime 0 -exec cp -r {} /logs/translogs/trans1logs/pretups_smsplogs/$dir1 \;
cd /logs/translogs/trans1logs/pretups_smsplogs/$dir1
gzip *
cd /logs/translogs/trans1logs/pretups_smsplogs
find Log* -ctime +10 -exec rm -rf {} \;


#### CronLogs
cd /logs/translogs/trans1logs/pretups_cronLogs
mkdir $dir1
cd /pretupsvar_trans1/pretups_cronLogs/oldlogs
find *.log.* -mtime 0 -exec cp -r {} /logs/translogs/trans1logs/pretups_cronLogs/$dir1 \;
cd /logs/translogs/trans1logs/pretups_cronLogs/$dir1
gzip *
cd /logs/translogs/trans1logs/pretups_cronLogs
find Log* -ctime +10 -exec rm -rf {} \;


####  SMSCGatewayLogs
cd /logs/translogs/trans1logs/SMSCGatewayLogs
mkdir $dir1
cd /pretupsvar_trans1/SMSCGatewayLogs/oldlogs
find *.log.* -mtime 0 -exec cp -r {} /logs/translogs/trans1logs/SMSCGatewayLogs/$dir1 \;
cd /logs/translogs/trans1logs/SMSCGatewayLogs/$dir1
gzip *
cd /logs/translogs/trans1logs/SMSCGatewayLogs
find Log* -ctime +10 -exec rm -rf {} \;


##############################################################################

###############Transaction Server Two #######################################
#### SMSR Logs
cd /logs/translogs/trans2logs/pretups_smsrlogs
mkdir $dir1
cd /pretupsvar_trans2/pretups_smsrlogs/oldlogs
find *.log.* -mtime 0 -exec cp -r {} /logs/translogs/trans2logs/pretups_smsrlogs/$dir1 \;
cd /logs/translogs/trans2logs/pretups_smsrlogs/$dir1
gzip *
cd /logs/translogs/trans2logs/pretups_smsrlogs
find Log* -ctime +10 -exec rm -rf {} \;


#### SMSP Logs
cd /logs/translogs/trans2logs/pretups_smsplogs
mkdir $dir1
cd /pretupsvar_trans2/pretups_smsplogs/oldlogs
find *.log.* -mtime 0 -exec cp -r {} /logs/translogs/trans2logs/pretups_smsplogs/$dir1 \;
cd /logs/translogs/trans2logs/pretups_smsplogs/$dir1
gzip *
cd /logs/translogs/trans2logs/pretups_smsplogs
find Log* -ctime +10 -exec rm -rf {} \;


#### CronLogs
cd /logs/translogs/trans2logs/pretups_cronLogs
mkdir $dir1
cd /pretupsvar_trans2/pretups_cronLogs/oldlogs
find *.log.* -mtime 0 -exec cp -r {} /logs/translogs/trans2logs/pretups_cronLogs/$dir1 \;
cd /logs/translogs/trans2logs/pretups_cronLogs/$dir1
gzip *
cd /logs/translogs/trans2logs/pretups_cronLogs
find Log* -ctime +10 -exec rm -rf {} \;


####  SMSCGatewayLogs
cd /logs/translogs/trans2logs/SMSCGatewayLogs
mkdir $dir1
cd /pretupsvar_trans2/SMSCGatewayLogs/oldlogs
find *.log.* -mtime 0 -exec cp -r {} /logs/translogs/trans2logs/SMSCGatewayLogs/$dir1 \;
cd /logs/translogs/trans2logs/SMSCGatewayLogs/$dir1
gzip *
cd /logs/translogs/trans2logs/SMSCGatewayLogs
find Log* -ctime +10 -exec rm -rf {} \;

#########################################################################################

###############Transaction Server Three #######################################
#### SMSR Logs
cd /logs/translogs/trans3logs/pretups_smsrlogs
mkdir $dir1
cd /pretupsvar_trans3/pretups_smsrlogs/oldlogs
find *.log.* -mtime 0 -exec cp -r {} /logs/translogs/trans3logs/pretups_smsrlogs/$dir1 \;
cd /logs/translogs/trans3logs/pretups_smsrlogs/$dir1
gzip *
cd /logs/translogs/trans3logs/pretups_smsrlogs
find Log* -ctime +10 -exec rm -rf {} \;


#### SMSP Logs
cd /logs/translogs/trans3logs/pretups_smsplogs
mkdir $dir1
cd /pretupsvar_trans3/pretups_smsplogs/oldlogs
find *.log.* -mtime 0 -exec cp -r {} /logs/translogs/trans3logs/pretups_smsplogs/$dir1 \;
cd /logs/translogs/trans3logs/pretups_smsplogs/$dir1
gzip *
cd /logs/translogs/trans3logs/pretups_smsplogs
find Log* -ctime +10 -exec rm -rf {} \;


#### CronLogs
cd /logs/translogs/trans3logs/pretups_cronLogs
mkdir $dir1
cd /pretupsvar_trans3/pretups_cronLogs/oldlogs
find *.log.* -mtime 0 -exec cp -r {} /logs/translogs/trans3logs/pretups_cronLogs/$dir1 \;
cd /logs/translogs/trans3logs/pretups_cronLogs/$dir1
gzip *
cd /logs/translogs/trans3logs/pretups_cronLogs
find Log* -ctime +10 -exec rm -rf {} \;


####  SMSCGatewayLogs
cd /logs/translogs/trans3logs/SMSCGatewayLogs
mkdir $dir1
cd /pretupsvar_trans3/SMSCGatewayLogs/oldlogs
find *.log.* -mtime 0 -exec cp -r {} /logs/translogs/trans3logs/SMSCGatewayLogs/$dir1 \;
cd /logs/translogs/trans3logs/SMSCGatewayLogs/$dir1
gzip *
cd /logs/translogs/trans3logs/SMSCGatewayLogs
find Log* -ctime +10 -exec rm -rf {} \;

#####################################################################################################

###############Transaction Server Four #######################################
#### SMSR Logs
cd /logs/translogs/trans4logs/pretups_smsrlogs
mkdir $dir1
cd /pretupsvar_trans4/pretups_smsrlogs/oldlogs
find *.log.* -mtime 0 -exec cp -r {} /logs/translogs/trans4logs/pretups_smsrlogs/$dir1 \;
cd /logs/translogs/trans4logs/pretups_smsrlogs/$dir1
gzip *
cd /logs/translogs/trans4logs/pretups_smsrlogs
find Log* -ctime +10 -exec rm -rf {} \;


#### SMSP Logs
cd /logs/translogs/trans4logs/pretups_smsplogs
mkdir $dir1
cd /pretupsvar_trans4/pretups_smsplogs/oldlogs
find *.log.* -mtime 0 -exec cp -r {} /logs/translogs/trans4logs/pretups_smsplogs/$dir1 \;
cd /logs/translogs/trans4logs/pretups_smsplogs/$dir1
gzip *
cd /logs/translogs/trans4logs/pretups_smsplogs
find Log* -ctime +10 -exec rm -rf {} \;


#### CronLogs
cd /logs/translogs/trans4logs/pretups_cronLogs
mkdir $dir1
cd /pretupsvar_trans4/pretups_cronLogs/oldlogs
find *.log.* -mtime 0 -exec cp -r {} /logs/translogs/trans4logs/pretups_cronLogs/$dir1 \;
cd /logs/translogs/trans4logs/pretups_cronLogs/$dir1
gzip *
cd /logs/translogs/trans4logs/pretups_cronLogs
find Log* -ctime +10 -exec rm -rf {} \;


####  SMSCGatewayLogs
cd /logs/translogs/trans4logs/SMSCGatewayLogs
mkdir $dir1
cd /pretupsvar_trans4/SMSCGatewayLogs/oldlogs
find *.log.* -mtime 0 -exec cp -r {} /logs/translogs/trans4logs/SMSCGatewayLogs/$dir1 \;
cd /logs/translogs/trans4logs/SMSCGatewayLogs/$dir1
gzip *
cd /logs/translogs/trans4logs/SMSCGatewayLogs
find Log* -ctime +10 -exec rm -rf {} \;

##################################################################################################
### Powered By Bharti(Rajeev)