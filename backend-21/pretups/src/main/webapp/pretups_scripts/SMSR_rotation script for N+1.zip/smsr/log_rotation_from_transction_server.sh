###################################################################
#                Cron Script                                       #
#                Bharti Telesoft LTD.                              #
#                Dated :05/05/2008                                 #
####################################################################
# check for Services On which node Services are running
/usr/local/bin/curl 'http://127.0.0.1:9898/pretups/test.html'
ret=`echo $?`
if [ $ret = 0 ] ; then
#echo "`uname -n` is active"
# Rotatelogs.sh
#echo " *************** Rotation of sms Logs********************************"

TOMLOG=/pretupsvar/pretups_smsrlogs/
OLDLOG=/pretupsvar/pretups_smsrlogs/oldlogs
cd $TOMLOG
datenow=`date +%m_%Y`
day=`date +%d`
day=`expr $day - 1`
datenow=$day"_"$datenow
cp catalina.out $OLDLOG/catalina.out.$datenow
> catalina.out
#cd $TOMOLDLOG
#find *.out* -ctime +2 -exec rm -f {} \;

cd $TOMLOG
cp PreTUPs_out.log $OLDLOG/PreTUPs_out.log.$datenow
> PreTUPs_out.log
mv *.log.* $OLDLOG/
cd $OLDLOG
find *.log.* -ctime +3 -exec rm -f {} \;
find catalina.out.* -mtime +0 -exec rm -f {} \;
find PreTUPs_out.log.* -mtime +0 -exec rm -f {} \;

#### Cronlogs truncation #####
TOMLOG=/pretupsvar/pretups_cronLogs
OLDLOG=/pretupsvar/pretups_cronLogs/oldlogs
cd $TOMLOG
cp scripts.log $OLDLOG/scripts.log.$datenow
> scripts.log
cp process_check.log $OLDLOG/process_check.log.$datenow
> process_check.log
> processes_check.log
cd $OLDLOG
find *.log.* -ctime +3 -exec rm -f {} \;




echo "[`date`] Truncate smsr Logs from Node [`uname -n`]" >> /pretupsvar/pretups_cronLogs/scripts.log
else
echo "`uname -n` is not active"
fi