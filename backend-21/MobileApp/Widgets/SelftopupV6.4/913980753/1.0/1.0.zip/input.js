// ENCRYPT PLUG-IN URL
var ENCRYPT_URL = "AES128Plugin:plugin.webaxn.comviva.com?";