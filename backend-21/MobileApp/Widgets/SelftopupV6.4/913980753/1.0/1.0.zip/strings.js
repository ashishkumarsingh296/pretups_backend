//Registeration

var STR_REG_SUBMIT = "YUP! NEXT...";
var STR_AGREE = "I Agree";
var STR_CANCEL = "Cancel";
var STR_PROFILE = "PROFILE";
var STR_TERM_TEXT = " I agree to the";
var MOBILE_LEN ="10";
var STR_FINALLY = "FINISH & SAVE";
var STR_NAME_TITLE ="Name";
var STR_MSISDN_TITLE ="Mobile";
var STR_TERMS = "Terms";
//smspin 

var STR_VERIFY = "VERIFY";
var STR_SMSPIN = "PIN(SMS)";
var SMSPIN_LEN = "4";
var STR_SMSVERIFY = "OK! AND NOW...";

//createPIN

var STR_CREATEPIN= "Create Pin";
var STR_PIN = "PIN";
var STR_CONFIRMPIN = "ConfirmPin";

//terms


var STR_TERMS_TEXT =" Terms";
var STR_TERMS_HEAD = "Terms";
var STR_TERM_SUBTITLE = "Terms of Services";
var STR_HASH = "#";
var STR_SEMICOLON = ";";
//var STR_TERMS = "Acceptance;Lorem ipsum dolor ist amet, consectetur adipiscing elit.Nulam mattis lobortis sollicitudin. Curabitur pretium vitae sem vel luctus.Cras venenatis luctus euismod.praesent condimentium uma vitae fringilla tristique,Quisque poseuere a sapien at fermentum.Suspendisse lectus ipsum,pellentesque mattis dui vel ,scelerisque ullamcorper magna.;duis commodo lorem eget vehicula faucibus dolor risus lacinia massa id aliquam ipsum neque sed nulla.Inter tincidunt mauris ut ante porttitor.#Under Advicement;Duis is quam ullamcorper,portitor orci eu,blandit erat Integer elementum justo et odio moleste ultrices in erat est,dapibus vel ultricies nec,venenatis lacus vivamus justo tellus facilsis et ultricies sit  amet felis tellus vestibu lum augue me feugaiat ac portutor id ,diagnissim vel arcu Maus luctus est eu dignissim.;Duis commodi lerem eget vehiculla faucibus,dolor risus lacin ia massa id aliquam ipsum neque sed nulla interger tincidunt mauris ut ante portitor.";
var STR_TERMS = ["Acceptance;" +
		"Lorem ipsum dolor ist amet, consectetur adipiscing elit.Nulam mattis lobortis sollicitudin. Curabitur pretium vitae sem vel luctus.Cras venenatis luctus euismod.praesent condimentium uma vitae fringilla tristique,Quisque poseuere a sapien at fermentum.Suspendisse lectus ipsum,pellentesque mattis dui vel ,scelerisque ullamcorper magna.;" +
		"duis commodo lorem eget vehicula faucibus dolor risus lacinia massa id aliquam ipsum neque sed nulla.Inter tincidunt mauris ut ante porttitor." +
		"#Under Advicement;" +
		"Duis is quam ullamcorper,portitor orci eu,blandit erat Integer elementum justo et odio moleste ultrices in erat est,dapibus vel ultricies nec,venenatis lacus vivamus justo tellus facilsis et ultricies sit  amet felis tellus vestibu lum augue me feugaiat ac portutor id ,diagnissim vel arcu Maus luctus est eu dignissim.;" +
		"Duis commodi lerem eget vehiculla faucibus,dolor risus lacin ia massa id aliquam ipsum neque sed nulla interger tincidunt mauris ut ante portitor."].join("");


var STROPTDOWN = "New version of PreTUPS application is available. Do you want to download now?";
var STRLATER = "Later";
var STRDOWNLOAD = "Download";
var STRFORCEDOWN = "Please download the new version of PreTUPS application to continue using this service.";
var STREXIT = "Exit";

//Recharge 

var STR_PRETUPS_TITLE = "PreTUPS";
var STR_SELF_RECHAGE_TITLE = "Recharge My Account";
var STR_ANOTHER_RECHAGE_TITLE = "Recharge for Someone else";//"Recharge Another Account";
var STR_TOPMEUP_TITLE = "Ask a Friend for Recharge";

var STR_MSISDN_TITLE = "+91";
var STR_AMOUNT="Amount";
var STR_AMOUNT_REQ = "Amount(Request)";
var STR_RECHARGENOW = "Recharge Now";
var STR_SENDREQUEST = "Send Request";
var STR_WELCOME ="welcome :)";

var STR_BUDDYTEXT = "Buddies";
var STR_SOSTEXT = "Fast Charge";
var STR_CARDSTEXT = "Cards";
var STR_ACCOUNTTEXT = "Settings";

var STR_ENABLE = true;
var STR_PAYTITLE = "Payment Option";
var STR_NOBAL_PAYTEXT = "Use my Current Balance";
var STR_PAYTEXT= "Use My Current Balance";
var STR_PAYCARD_TEXT = "Or Use Your Card";

var STR_MAKEPAY_HEADING = "Make Payment";
var STR_CONFIRM_HEADING = "Confirm Payment";
var STR_ACCEPT = "Accept";
var STR_CANCEL = "Cancel";
var STR_ADD = "Add";
var STR_NEWCARD = "New Card";
var STR_CONFIRM = "Done";
var STR_TRYAGAIN = "Try Again";

var STR_ADDBUDDY_TITLE = "Add Buddy";
var STR_RECH_BUDDY = "Recharge Buddy";
var STR_DEL_BUDDY  = "Delete Buddy";
var STR_BUDDY_HEADING = "Buddies";	

var STR_CONF = "Confirm";


var STR_PIN_CHECK = true;

var STR_INFO = "Your transaction $transId for $ $amount on number $msisdn has been processed on your Prepaid balance.";

/*payment status start*/

STR_SUCCESS = "Success!!";
STR_FAILURE = "Transaction Failed!!";
STR_SUCCESS_CODE = "200";
/*payment status end*/

var STR_HASH = "#";
var STR_SEMICOLON = ";";

/*SOS string  start*/
var STR_SOSNO = "No";
var STR_SOSYES = "Yes";
var STR_TOP_TEXT = "Do you want to send an SoS request via SMS?";
var STR_BOTTOM_TEXT = "Get an emergency talktime loan from your Operator";
var STR_RESPONSE_MSG_TEXT = "SoS request has been send to the Operator.Your account will be credited with emergency Talktime.";
// Talk meup responseText
var STR_TALKMEUP_RESPMSG = "Recharge request has been send to the your Friend.";
//var STR_TEXT1 = "Your operator will recharge";  
//var STR_TEXT2 = "you for a limited amount.";

/*SOS string  end*/

/*BUDDY start*/	

var STR_BUDDYHEADING = "Add Buddy";
var STR_BUDDYNAME = "Name";
var STR_BUDDYNO =	"+91";
var STR_BUDDYAMT =  "Default Recharge Amt";
var STR_BUDDYCONFIRM = "Confirm";
var STR_BUDDYADD = "Add";
var STR_BUDDYCANCEL = "Cancel";
var STR_NOBUDDIES = "No Buddies";
var STR_NOBUDDIESPAGE_TEXT = "There are no buddies added to your account yet.Add your friends n family as buddies and manage their recharge.";

/*BUDDY end*/	

/*ChangePin start*/
var STR_ACCOUNT_TITLE = "Account";
var STR_CHANGEPIN_TEXT = "Change Pin";
var STR_OLDPIN_TITLE = "Old Pin"; 
var STR_NEWPIN_TITLE = "New Pin";
var STR_CNEWPIN_TITLE = "Confirm Pin";
var STR_CHANGE_TEXT = "Change";
var STR_PINCHANGECHECK = "Show Pin";


/*ChangePin end*/



//Cards
var STR_CARD_TITLE = "Cards";
var STR_ADDCARD_TEXT = "Add Card";
var STR_NEWCARD_TEXT = "New Card";
var STR_DELETECARD_TEXT = "Delete Card";
var STR_ADD = "Add";
var STR_PAY = "Pay";
var STR_CANCEL = "Cancel";
var STR_EDIT = "Edit";
var STR_SAVE = "Save";
var STR_DELETE = "Delete";
var STR_CONF = "Confirm";

var STR_CARDNAME_TITLE = "Name on Card";
var STR_CARDNUM_TITLE = "Card Number";
var STR_CVV_TEXT = "CVV";
var STR_CVV_TITLE = "CVV/CVC";
var STR_EXPIRY_TITLE = "Expiry";
var STR_NICKNAME_TITLE = "Nickname";
var STR_ADDCARDCHECK = "Save this Card";
var STR_NOCARD_TEXT = "There are no Cards linked to your account yet.Add a Card now to start recharging";//"You Currently have no Card";
// pincheck
var STR_PIN_CHECK = true;
var height= widget.fetchScreenHeight();
if("" != nullorUndefCheck(height))
{
height = Number(height)/2-80;
}
var NOCARD_MARGIN = height;

var STR_HASH = "#";
var STR_SEMICOLON = ";";






