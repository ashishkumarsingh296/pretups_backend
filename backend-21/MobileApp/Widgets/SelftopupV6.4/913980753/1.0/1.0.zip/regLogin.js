//var imagePath = "wgt:214807648/1.0/"+widget.resourcePath+"/";
function terms()
{

	/*document.getElementById("termssubtitle").innerHTML=STR_TERM_SUBTITLE;
	document.getElementById("acceptance").innerHTML=STR_ACCEPTANCE;
	document.getElementById("acceptancetext").innerHTML=STR_ACCEPTANCE_TEXT;
	document.getElementById("acceptancesubtext").innerHTML=STR_ACCEPTANCE_TEXT_SUB;
	document.getElementById("advicement").innerHTML=STR_ADVICEMENT;
	document.getElementById("advicementtext").innerHTML=STR_ADVICEMENT_TEXT;
	document.getElementById("advicementsubtext").innerHTML=STR_ADVICEMENT_TEXT_SUB;
	document.getElementById("terms").style.display = "block";*/

	var str = "";
	var regflag = widget.retrieveWidgetUserData(264711061,"regFlag");
	var UCODE = Math.floor((Math.random() * 10000000000) + 1);
	var IMEI = widget.getHeader("imei");
	UCODE = "1234567890";
	//IMEI  = "358422050496045";
	widget.logWrite(7,"regFlag Value::"+regflag);
	
	if(regflag == true || regflag == "true")
	{
		window.location = "wgt:264711061/1.0";

	}
	else
	{
		str +="<div  align='left' width='100%' class='c3lTitle bgColor topMargin'><span  class='topSize' align='center' valign='middle' >"+STR_TERMS_HEAD+"</span><hr></div>";
		str +="<div><span id='termssubtitle' class='marginLeft20 termsubtitle'>"+STR_TERM_SUBTITLE+"</span></div>";
			
		var rawFile = new XMLHttpRequest();
	    rawFile.open("GET", "terms.txt", false);
	    var allText="";

	    rawFile.onreadystatechange = function ()
	    {
	        if(rawFile.readyState === 4)
	        {
	            if(rawFile.status === 200 || rawFile.status == 0)
	            {
	                allText = rawFile.responseText;
	            }
	        }
	    }
	    rawFile.send(null);
		
	    str +="<div>"+allText+"</div>";
		//str +="<div class='c3lNavigation'><div class='c3lMenuGroup'><a width='50%' style='margin-right:7%' href=\"exit:\" class='c3lMenuGroup buttonBg1'><span class='buttonText'  align='center'>"+STR_CANCEL+"</span></a><a id='back' href=\"sms://to=+919986027668&text=pretups IMEI="+IMEI+";UCODE="+UCODE+"&encrypt=false&action=wgt:950181717/1.0:SubscriberRegReq('"+IMEI+"','"+UCODE+"');\"  width='49%' class='c3lMenuGroup buttonBg1'><span class='buttonText'  align='center'>"+STR_AGREE+"</span></a></div></div>";
		 str +="<div class='c3lNavigation'><div class='c3lMenuGroup'><a width='50%' style='margin-right:7%' href=\"exit:\" class='c3lMenuGroup buttonBg1'><span class='buttonText'  align='center'>"+STR_CANCEL+"</span></a><a id='back' href=\"wgt:950181717/1.0:SubscriberRegReq('"+IMEI+"','"+UCODE+"');\"  width='49%' class='c3lMenuGroup buttonBg1'><span class='buttonText'  align='center'>"+STR_AGREE+"</span></a></div></div>";
		//str = [str,"<specialcache name='terms' url='termscache()' type='screen'/>"].join("");
		
		document.getElementById("terms").innerHTML = str;
		document.getElementById("terms").style.display = "block";
	}
}

/*function termscache()
{
	terms();
}*/


function createPIN(smspin)
{
	/*document.getElementById("pin").title=STR_PIN;
	document.getElementById("cpin").title=STR_CONFIRMPIN;
	document.getElementById("createpin").innerHTML=STR_FINALLY;
	document.getElementById("createPIN").style.display = "block";*/
	
	var str = "";
	var divEle = "";
	
	str +="<setvar name='pin' value=''/><setvar name='cpin' value=''/>";
	str +="<div  align='left' width='100%' class='c3lMenuGroup bgColor marginBottom20'><a href='javascript:terms();'><img  width='"+backImgWidth+"px' height='"+backImgWidth+"px' align='left' resimg='icon_back.9.png' src='"+imagePath+"icon_back.9.png'/></a><span class='topText' id='paytitle' valign='middle' align='center' style='margin-left:-"+backImgWidth+"px'>"+STR_CREATEPIN+"</span><hr></div>";
	str +="<input  class='inputBg' id='pin' name='pin' type='numpassword'	maxLength='"+PIN_LENGTH+"' encrypt='true' emptyok='false' title='"+STR_PIN+"' />";
	str +="<input  	class='inputBg' id='cpin' name='cpin' type='numpassword'	maxLength='"+PIN_LENGTH+"' encrypt='true' emptyok='false' title='"+STR_CONFIRMPIN+"' />";
	str +="<a href=\"wgt:950181717/1.0:sendSubsChangepinReq('"+smspin+"',$pin,$cpin);\" class='c3lMenuGroup buttonBg'><span class='buttonText' id='createpin' align='center'>"+STR_FINALLY+"</span></a>";	
	
	var menu = window.menu;
	addMenu(menu, "back", "wgt:913980753/1.0:terms();","" , 1, 0);	
	
	str = [str,"<specialcache name='createPIN' url='createpincache()' type='screen'/>"].join("");
	
	widget.savePermanent = SAVE_PERMINENT;
	
	divEle = document.getElementById("createPIN");
	divEle.innerHTML=str;
	divEle.style.display = "block";	
}

function createpincache()
{
	createPIN();
}





