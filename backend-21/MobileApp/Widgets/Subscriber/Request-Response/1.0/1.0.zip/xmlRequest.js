var mobile = widget.retrieveUserData("regMSISDN");
var imei = widget.getHeader("IMEI");
//imei ="353743053371925";
widget.logWrite(7,"imeiNo mobile..."+imei+"mobile::"+mobile);
var date = changetimeformat();
var widget = window.widget ;	
var xmlHttp;
/* subscriber APP URL start */

var url=PreTUPSSERVER + "?REQUEST_GATEWAY_CODE="+REQUEST_GATEWAY_CODE+"&REQUEST_GATEWAY_TYPE="+REQUEST_GATEWAY_TYPE+"&LOGIN="+LOGIN+"&PASSWORD="+PASSWORD+"&SOURCE_TYPE="+SOURCE_TYPE+"&SERVICE_PORT="+SERVICE_PORT;
//var url = "http://172.16.7.194:1515/pretups/SelfTopUpReceiver?REQUEST_GATEWAY_CODE=STUGW&REQUEST_GATEWAY_TYPE=STUGW&LOGIN=pretups&PASSWORD=pretups123&SOURCE_TYPE=plain&SERVICE_PORT=190";
//var url = "http://124.153.86.45:5554/pretups/C2SReceiver?REQUEST_GATEWAY_CODE=EXTGW&REQUEST_GATEWAY_TYPE=EXTGW&LOGIN=pretups&PASSWORD=pretups123&SOURCE_TYPE=EXTGW&SERVICE_PORT=190";


if(DEMO_FLAG == 1 || DEMO_FLAG == "1")
{
	var demo_url = DEMO_URL ;
	url = demo_url;
}
widget.logWrite(7,"url for Subscriber PreTUPS demo flag:: "+DEMO_FLAG);
widget.logWrite(7,"url for Subscriber PreTUPS :: "+url);

/* subscriber APP URL end */

/*this function for User Registration of PreTUPS App*/

function SubscriberRegReq(imei,ucode)
{

	widget.clearUserData("eKey");
	widget.clearUserData("regMSISDN");
	
	//var uniqueNo = Math.floor((Math.random() * 10000000000) + 1);
	ucode = nullorUndefCheck(ucode);
	imei = nullorUndefCheck(imei);
	//imei ="353743053371925";
	var postData = "";
	var cdrStr="";
	
	//TYPE=REGREQ&IMEI=<IMEI no>&MSISDN=<Initiating Subscriber MSISDN>&LANGUAGE1=en&EMAILID=<Subscriber e-mail id>
	//var postdata = "TYPE="+TYPE+"&MSISDN="+msisdn+"&IMEI="+imei+"&EMAILID="+EMAIL; // working
	if(DEMO_FLAG == 1 || DEMO_FLAG == "1")
	{
		postData = "TYPE=STPREGREQ&IMEI="+imei+"&UCODE="+ucode;
	}else
	{
	url = url+"&TYPE="+SUBS_REG_TYPE+"&MSISDN="+DEF_MSISDN+"&UCODE="+ucode+"&IMEI="+imei;
	}
	//var postdata = "TYPE=STPREGREQ&MSISDN=7285508430&IMEI=353743053371926&EMAILID=abc@xyz.com";
	widget.logWrite(7,"SubscriberRegReq postdata request::"+postData);

	if (null == xmlHttp)
	{
		xmlHttp = new XMLHttpRequest () ;	
		
	}
	if (xmlHttp)
	{
		xmlHttp.onreadystatechange = function()
		{
			if (4 == xmlHttp.readyState &&  200 == xmlHttp.status)
			{
				//var xmlDoc = xmlHttp.responseXML ;
				var xmlText = xmlHttp.responseText ;
				//var xmlText = "TYPE=PREGRES&TXNSTATUS=200&MESSAGE=Registration Successful&ENK=33F876F832F7592C";
				widget.logWrite(7,"response for SubscriberRegReq::"+xmlText);
				if (xmlText != null && !xmlText.indexOf("null") > -1 )
				{
					
					var txn_status 	= responseStr(xmlText, STR_TXNSTATUS) ;
					var txn_message = responseStr(xmlText, STR_TXNMESSAGE) ;
					var mobileNo  = responseStr(xmlText, STR_MSISDN) ;
					var encryptKey  = responseStr(xmlText, STR_EKEY) ;
					cdrStr +="|"+txn_status+"|"+txn_message+"|"+changetimeformat();
					widget.writeCDR (1, cdrStr) ;
					widget.logWrite(7,"cdrstr logs.."+cdrStr);
					
					widget.storeUserData("ekey",encryptKey);
					widget.storeUserData("regMSISDN",mobileNo);
					
					//if(txn_status == "4010")
					if(txn_status == STR_SUCCESS)
					{
			
						//	widget.storeUserData("regMSISDN",msisdn);
						window.location = "wgt:913980753/1.0:createPIN()";
					}/*else if(txn_status == "4010")
					{
						widget.storeUserData("ekey",encryptKey);
						widget.storeUserData("regMSISDN",msisdn);
						//	widget.storeUserData("regMSISDN",msisdn);
						window.location = "wgt:913980753/1.0:smsPinVerify()";
					}*/
					else if(txn_status == STR_SECLEVELREG_RES_CODE)
					{
						
						
						window.location = "wgt:913980753/1.0:createPIN()";
					}else if(txn_status == STR_REINSTALL_RES_CODE)
					{
						
						window.location = "wgt:264711061/1.0";
					}
					else
					{
						divElement= document.getElementById("toast");
						divElement.title = "PreTUPS";
						divElement.innerHTML = txn_message;
						divElement.style.display = "block";
					}
				}else
				 {
					divElement= document.getElementById("toast");
					divElement.title = "PreTUPS";
					divElement.innerHTML = STR_SERVICE_ERROR ;
					divElement.style.display = "block";
				 }
			}else
			{
				var str;
				var divElement;
				str = STR_SERVER_ERROR;
				divElement= document.getElementById("toast");
				divElement.title = "PreTUPS";
				divElement.innerHTML = str;
				divElement.style.display = "block";
			}  				


		};
	}
	xmlHttp.open ("POST", url , false) ;
	xmlHttp.setRequestHeader("Content-Type", "plain");

	xmlHttp.setRequestHeader("Connection", "close");
	
	cdrStr += changetimeformat()+"| Subscriber Registration";
	xmlHttp.send (postData) ;


}

/*function checkregMSISDN(){

	var postdata = "";	
	
	TYPE=STPRCREQ&IMEI=<IMEI no>&MSISDN=<Initiating Subscriber MSISDN>&PIN=<Subscriber PIN>&MSISDN2=<Receiver MSISDN>&EXTREFNUM=<Unique Reference number in Retailer App>&AMOUNT=<Amount>&SELECTOR=1&LANGUAGE1=en&LANGUAGE2=en&HOLDERNAME=<Holder Name>&CARDNO=<Card number>&EDATE=<Card�s Expiry date>&CVV=<cvv>
	if(SENDENCRYPTREQ)
	{
		postdata = "TYPE=" + SUBS_SMSPIN_TYPE + "&MSISDN="+ mobile +"&MESSAGE="+getEncrypt("IMEI=" + imei + "&&PIN=" + pin+"&LANGUAGE1=" + LANGUAGE1);
	}else
	{
		postdata = "TYPE=" + SUBS_SMSPIN_TYPE + "&MSISDN="+ mobile +"&MESSAGE=IMEI=" + imei + "&&PIN=" + pin+"&LANGUAGE1=" + LANGUAGE1;
	}
	
	widget.logWrite(7,"sendSMSpinReq postdata request::"+postdata);
	if (null == xmlHttp)
	{
		xmlHttp = new XMLHttpRequest () ;			
	}
	if (xmlHttp)
	{
		xmlHttp.onreadystatechange = function()
		{
			if (4 == xmlHttp.readyState &&  200 == xmlHttp.status)
			{
				//var xmlDoc = xmlHttp.responseXML ;
				//var xmlText = xmlHttp.responseText ;
				var xmlText = "TYPE=PREGRES&TXNSTATUS=200&MESSAGE=SMSPIN Successful";
				widget.logWrite(7,"xml response for checkregMSISDN: "+xmlText);
				if (xmlText != null && !xmlText.indexOf("null") > -1 )
				{
					var txn_status 	= responseStr(xmlText, STR_TXNSTATUS) ;
					var txn_message = responseStr(xmlText, STR_TXNMESSAGE) ;
					if(txn_status == STR_SUCCESS)
					{
						window.location = "wgt:264711061/1.0:pretupsHome(1)";
					}else
					{
						divElement= document.getElementById("toast");
						divElement.title = "PreTUPS";
						divElement.innerHTML = txn_message;
						divElement.style.display = "block";
					}
				}else
				 {
					divElement= document.getElementById("toast");
					divElement.title = "PreTUPS";
					divElement.innerHTML = STR_SERVICE_ERROR;
					divElement.style.display = "block";
				 }
				}else
				{
					var str;
					var divElement;
					str = STR_SERVER_ERROR;
	
					divElement= document.getElementById("toast");
					divElement.title = "PreTUPS";
					divElement.innerHTML = str;
					divElement.style.display = "block";
				}  			

		};
		xmlHttp.open ("POST", url , false) ;
		xmlHttp.setRequestHeader("Content-Type", "plain");
		xmlHttp.setRequestHeader("Connection", "close");
		cdrStr += changetimeformat()+"| MSISDN check";
		xmlHttp.send (postdata) ;
	}
}*/
/*this function for First Time change PIN and PIN change Request of User */
function sendSubsChangepinReq(pin,newpin,confirmpin,type) {

	widget.logWrite(7,"confirmpin  type:"+type);
	
	pin = nullorUndefCheck(pin);
	newpin = nullorUndefCheck(newpin);
	confirmpin = nullorUndefCheck(confirmpin);
	type = nullorUndefCheck(type);
	
	if("" == nullorUndefCheck(mobile))
	{
		mobile = widget.retrieveWidgetUserData(950181717,"regMSISDN");
	}
	if("" == nullorUndefCheck(pin))
	{
		pin = DEF_PIN;
	}
	widget.logWrite(7,"mobile  type:"+type);
	var cdrStr ="";
	var divElement = "";
	var postdata = "";
	/*TYPE=P2PCPREQ&IMEI=<IMEI no>&MSISDN=<Initiating Subscriber MSISDN>&OLDPIN=<Subscriber Old PIN>
			&NEWPIN=<Subscriber New PIN>CONFIRMPIN=<Subscriber Confirm PIN>&LANGUAGE1=en
	 */

	if (newpin != confirmpin) 
	{
		var str = STR_PINCHECK;
		 divElement = document.getElementById("toast");
		divElement.title= "PreTUPS";
		divElement.innerHTML = str;
		divElement.style.display = "block";
	}else
	{
		if(SENDENCRYPTREQ)
		{
			postdata ="TYPE=" + SUBS_CHANGEPIN_TYPE + "&MSISDN=" + mobile + "&Message="+getEncrypt("IMEI=" + imei + "&OLDPIN=" + pin + "&NEWPIN=" + newpin + "&CONFIRMPIN=" + confirmpin); 
		}else
		{
			postdata ="TYPE=" + SUBS_CHANGEPIN_TYPE + "&MSISDN=" + mobile + "&Message=IMEI=" + imei + "&OLDPIN=" + pin + "&NEWPIN=" + newpin + "&CONFIRMPIN=" + confirmpin;	
		}
		
		widget.logWrite(7, "sendSubsChangepinReq postdata request:: " + postdata);
		if (null == xmlHttp)
		{
			xmlHttp = new XMLHttpRequest () ;			
		}
		if (xmlHttp)
		{
			xmlHttp.onreadystatechange = function()
			{
				if (4 == xmlHttp.readyState &&  200 == xmlHttp.status)
				{
					//var xmlDoc = xmlHttp.responseXML ;
					var xmlText = xmlHttp.responseText ;
					//var xmlText = "TYPE=PREGRES&TXNSTATUS=200&MESSAGE=PIN CHANGED"; 
					cdrStr +="|"+txn_status+"|"+txn_message+"|"+changetimeformat();
					widget.writeCDR (1, cdrStr) ;
					widget.logWrite(7,"cdrstr logs.."+cdrStr);

					widget.logWrite(7,"response for sendSubsChangepinReq:"+xmlText );
					if (xmlText != null && !xmlText.indexOf("null") > -1 )
					{
					
						var txn_status = responseStr(xmlText, STR_TXNSTATUS) ;
						var txn_message = responseStr(xmlText, STR_TXNMESSAGE) ;
						cdrStr +="|"+txn_status+"|"+txn_message+"|"+changetimeformat();
						//widget.writeCDR (1, cdrStr) ;
						widget.logWrite(7,"cdrstr logs.."+cdrStr);
						cdrcommon(cdrStr);
						if(txn_status == STR_SUCCESS)
						{	
							widget.storeUserData("regPin",newpin);
							if(type == 1 || type == "1")
							{
								divElement= document.getElementById("toast");
								divElement.title = "PreTUPS";
								divElement.innerHTML = txn_message+"<setvar name='oldpin' value=''/><setvar name='newpin' value=''/><setvar name='cnewpin' value=''/>";
								divElement.style.display = "block";

							}else
							{
							window.location = "wgt:264711061/1.0";
							}

						}else
						{
							divElement= document.getElementById("toast");
							divElement.title = "PreTUPS";
							divElement.innerHTML = txn_message;
							divElement.style.display = "block";
						}
					}else
					 {
						divElement= document.getElementById("toast");
						divElement.title = "PreTUPS";
						divElement.innerHTML = STR_SERVER_ERROR;
						divElement.style.display = "block";
					 }
				}else
				{
					var str;
					 divElement;
					str = STR_SERVICE_ERROR;
					divElement= document.getElementById("toast");
					divElement.title = "PreTUPS";
					divElement.innerHTML = str;
					divElement.style.display = "block";
				}  			
			};


			xmlHttp.open ("POST", url , false) ;
			xmlHttp.setRequestHeader("Content-Type", "plain");
			xmlHttp.setRequestHeader("Connection", "close");
			cdrStr += changetimeformat()+"| Subscriber pinChange";
			xmlHttp.send (postdata) ;
		}


	}
}



/*this function for subscriber self/another request of PreTUPS*/
function sendP2PRechargeReq(){
	
	var cdrStr = "";
	var txn_status = "";
	var txn_message = "";
	var postdata = "";
	
	var pin = widget.retrieveWidgetSecureUserData(264711061,"enteredpin");
	var amount = widget.retrieveWidgetUserData(264711061,"amount");
	var receiverMSISDN = widget.retrieveWidgetUserData(264711061,"msisdn");
	pin = nullorUndefCheck(pin);
	rechargeAmount = nullorUndefCheck(amount);
	receiverMSISDN = validateMSISDN(nullorUndefCheck(receiverMSISDN));

	

	//TYPE=STPPRCREQ&IMEI=<IMEI no>&MSISDN=<Initiating Subscriber MSISDN>&PIN=<Subscriber PIN>&MSISDN1=<Receiver MSISDN>&EXTREFNUM=<Unique Reference number in Retailer App>&AMOUNT=<Amount>&SELECTOR=1&LANGUAGE1=en&LANGUAGE2=en
	if(SENDENCRYPTREQ)
	{
		postdata ="TYPE=" + SUBS_P2P_TYPE + "&MSISDN=" + mobile + "&Message="+getEncrypt("IMEI=" + imei + "&PIN=" + pin + "&MSISDN1=" + receiverMSISDN + "&AMOUNT=" + rechargeAmount + "&SELECTOR=" + SELECTOR + "&LANGUAGE1=" + LANGUAGE1);
	}else
	{
		postdata ="TYPE=" + SUBS_P2P_TYPE + "&MSISDN=" + mobile + "&Message=IMEI=" + imei + "&PIN=" + pin + "&MSISDN1=" + receiverMSISDN + "&AMOUNT=" + rechargeAmount + "&SELECTOR=" + SELECTOR + "&LANGUAGE1=" + LANGUAGE1;
	}
	widget.logWrite(7,"sendP2PRechargeReq postdata request::"+postdata);
	if (null == xmlHttp)
	{
		xmlHttp = new XMLHttpRequest () ;			
	}
	if (xmlHttp)
	{
		xmlHttp.onreadystatechange = function()
		{
			if (4 == xmlHttp.readyState &&  200 == xmlHttp.status)
			{
				var xmlDoc = xmlHttp.responseXML ;
				var xmlText = xmlHttp.responseText ;
				widget.logWrite(7,"response for sendP2PRechargeReq:"+xmlText);
				if (xmlText != null && !xmlText.indexOf("null") > -1 )
				{
					 txn_status = responseStr(xmlText, STR_TXNSTATUS) ;
					txn_message = responseStr(xmlText, STR_TXNMESSAGE) ;
					cdrStr +="|"+txn_status+"|"+txn_message+"|"+changetimeformat();
					//widget.writeCDR (1, cdrStr) ;
					widget.logWrite(7,"cdrstr logs.."+cdrStr);
					cdrcommon(cdrStr);
					window.location = "wgt:264711061/1.0:payStatus('"+txn_status+"','"+txn_message+"')";

				}else
				 {
					/*divElement= document.getElementById("post1");
					divElement.title = "PreTUPS";
					divElement.innerHTML = STR_SERVER_ERROR;
					divElement.style.display = "block";*/
					window.location = "wgt:264711061/1.0:payStatus('"+txn_status+"','"+STR_SERVER_ERROR+"')";
				 }
			}else
			{
				
				var divElement;
				//str = STR_SERVICE_ERROR;
				window.location = "wgt:264711061/1.0:payStatus('"+txn_status+"','"+STR_SERVICE_ERROR+"')";
				/*divElement= document.getElementById("post1");
				divElement.title = "PreTUPS";
				divElement.innerHTML = str;
				divElement.style.display = "block";*/
			}  				
		};


		xmlHttp.open ("POST", url , false) ;
		xmlHttp.setRequestHeader("Content-Type", "plain");
		xmlHttp.setRequestHeader("Connection", "close");
		cdrStr += changetimeformat()+"| P2P Recharge ";

		xmlHttp.send (postdata) ;
	}


}

/*this is for card recharge of subscriber */
function sendSubsCardRechReq(cvv,nickName){

	var cdrStr = "";
	var postdata = "";
	var txn_status="";
	var txn_message="";
	
	var pin = widget.retrieveWidgetSecureUserData(264711061,"enteredpin");
	var amount = widget.retrieveWidgetUserData(264711061,"amount");
	var receiverMSISDN = widget.retrieveWidgetUserData(264711061,"msisdn");
	pin = nullorUndefCheck(pin);
	rechargeAmount = nullorUndefCheck(amount);
	receiverMSISDN = validateMSISDN(nullorUndefCheck(receiverMSISDN));
	
	if("" == nullorUndefCheck(nickName))
	{
	 nickName = widget.retrieveWidgetUserData(264711061,"nickName");
	}
		
		/*TYPE=STPRCREQ&IMEI=<IMEI no>&MSISDN=<Initiating Subscriber MSISDN>&PIN=<Subscriber PIN>&MSISDN2=<Receiver MSISDN>&EXTREFNUM=<Unique Reference number in Retailer App>&AMOUNT=<Amount>&SELECTOR=1&LANGUAGE1=en&LANGUAGE2=en&NNAME=<Subscriber Nick Name>&CVV=<cvv>*/
		if(SENDENCRYPTREQ)
		{
			postdata = "TYPE=" + SUBS_CARD_RECH_TYPE + "&MSISDN="+ mobile +"&Message="+getEncrypt("IMEI=" + imei + "&PIN=" + pin + "&MSISDN2=" + receiverMSISDN + "&AMOUNT=" + amount + "&SELECTOR=" + SELECTOR + "&NNAME=" + nickName + "&CVV=" + cvv);
		}else
		{
			postdata = "TYPE=" + SUBS_CARD_RECH_TYPE + "&MSISDN="+ mobile +"&Message=IMEI=" + imei + "&PIN=" + pin + "&MSISDN2=" + receiverMSISDN + "&AMOUNT=" + amount + "&SELECTOR=" + SELECTOR + "&NNAME=" + nickName + "&CVV=" + cvv;
		}
		widget.logWrite(7,"sendSubsCardRechReq postdata request::"+postdata);
		if (null == xmlHttp)
		{
			xmlHttp = new XMLHttpRequest () ;			
		}
		if (xmlHttp)
		{
			xmlHttp.onreadystatechange = function()
			{
				if (4 == xmlHttp.readyState &&  200 == xmlHttp.status)
				{
					var xmlDoc = xmlHttp.responseXML ;
					var xmlText = xmlHttp.responseText ;
					widget.logWrite(7,"response for sendSubsCardRechReq: "+xmlText);
					if (xmlText != null && !xmlText.indexOf("null") > -1 )
					{
						txn_status 	= responseStr(xmlText, STR_TXNSTATUS) ;
						txn_message = responseStr(xmlText, STR_TXNMESSAGE).toString() ;
						cdrStr +="|"+txn_status+"|"+txn_message+"|"+changetimeformat();
						widget.writeCDR (1, cdrStr) ;
						widget.logWrite(7,"cdrstr logs.."+cdrStr);
						cdrcommon(cdrStr);
						window.location = "wgt:264711061/1.0:payStatus('"+txn_status+"','"+txn_message+"')";

						
					}else
					 {
						/*divElement= document.getElementById("post1");
						divElement.title = "PreTUPS";
						divElement.innerHTML = STR_SERVER_ERROR;
						divElement.style.display = "block";*/
						window.location = "wgt:264711061/1.0:payStatus('"+txn_status+"','"+STR_SERVER_ERROR+"')";
					 }
				}else
				{
					/*var str;
					var divElement;
					str = STR_SERVICE_ERROR;

					divElement= document.getElementById("post1");
					divElement.title = "PreTUPS";
					divElement.innerHTML = str;
					divElement.style.display = "block";*/
					window.location = "wgt:264711061/1.0:payStatus('"+txn_status+"','"+STR_SERVICE_ERROR+"')";
				}  			

			};
			xmlHttp.open ("POST", url , false) ;
			xmlHttp.setRequestHeader("Content-Type", "plain");
			xmlHttp.setRequestHeader("Connection", "close");
			cdrStr += changetimeformat()+"| Card Recharge";

			xmlHttp.send (postdata) ;
		}
	
}
function sendBuddyRech(nickName,amount,pin){

	var cdrStr = "";
	var postdata = "";
	var txn_status="";
	var txn_message="";
	
	
	pin = nullorUndefCheck(pin);
	nickName = nullorUndefCheck(nickName);
	amount = nullorUndefCheck(amount);
	if( "" == nullorUndefCheck(mobile))
	{
		mobile = widget.retrieveWidgetUserData(950181717,"regMSISDN");	
	}
	
	
	//TYPE=PRCREQ&IMEI=<IMEI no>&MSISDN=<Initiating Subscriber MSISDN>&BUDDYNNAME=<Buddy Nick Name>& AMOUNT=<Default Amount>&LANGUAGE1=en&PIN=<Subscriber PIN>
	
		if(SENDENCRYPTREQ)
		{
			postdata = "TYPE=" + BUDDY_RECH_TYPE + "&MSISDN="+ mobile +"&Message="+getEncrypt("IMEI=" + imei + "&PIN=" + pin + "&BUDDYNNAME=" + nickName + "&AMOUNT=" + amount + "&LANGUAGE1=" + LANGUAGE1);
		}else
		{
			postdata = "TYPE=" + BUDDY_RECH_TYPE + "&MSISDN="+ mobile +"&Message=IMEI=" + imei + "&PIN=" + pin + "&BUDDYNNAME=" + nickName + "&AMOUNT=" + amount + "&LANGUAGE1=" + LANGUAGE1;
		}
		widget.logWrite(7,"sendBuddyRech postdata request::"+postdata);
		if (null == xmlHttp)
		{
			xmlHttp = new XMLHttpRequest () ;			
		}
		if (xmlHttp)
		{
			xmlHttp.onreadystatechange = function()
			{
				if (4 == xmlHttp.readyState &&  200 == xmlHttp.status)
				{
					var xmlDoc = xmlHttp.responseXML ;
					var xmlText = xmlHttp.responseText ;
					widget.logWrite(7,"response for sendBuddyRech: "+xmlText);
					if (xmlText != null && !xmlText.indexOf("null") > -1 )
					{
						txn_status 	= responseStr(xmlText, STR_TXNSTATUS) ;
						txn_message = responseStr(xmlText, STR_TXNMESSAGE).toString() ;
						cdrStr +="|"+txn_status+"|"+txn_message+"|"+changetimeformat();
						widget.writeCDR (1, cdrStr) ;
						widget.logWrite(7,"cdrstr logs.."+cdrStr);
						cdrcommon(cdrStr);
						window.location = "wgt:264711061/1.0:payStatus('"+txn_status+"','"+txn_message+"')";

						
					}else
					 {
						/*divElement= document.getElementById("post1");
						divElement.title = "PreTUPS";
						divElement.innerHTML = STR_SERVER_ERROR;
						divElement.style.display = "block";*/
						window.location = "wgt:264711061/1.0:payStatus('"+txn_status+"','"+STR_SERVER_ERROR+"')";
					 }
				}else
				{
					/*var str;
					var divElement;
					str = STR_SERVICE_ERROR;

					divElement= document.getElementById("post1");
					divElement.title = "PreTUPS";
					divElement.innerHTML = str;
					divElement.style.display = "block";*/
					window.location = "wgt:264711061/1.0:payStatus('"+txn_status+"','"+STR_SERVICE_ERROR+"')";
				}  			

			};
			xmlHttp.open ("POST", url , false) ;
			xmlHttp.setRequestHeader("Content-Type", "plain");
			xmlHttp.setRequestHeader("Connection", "close");
			cdrStr += changetimeformat()+"| Card Recharge";

			xmlHttp.send (postdata) ;
		}
	
}

/*this is for adhoc recharge of subscriber */
function sendSubsAdhocRechReq(cardName,cardNum,cvv,expiry,nickName,saveCardCheck){

	
	widget.logWrite(7,"sendSubsAdhocRechReq saveCard"+saveCardCheck);
	var pin = widget.retrieveWidgetSecureUserData(264711061,"enteredpin");
	var amount = widget.retrieveWidgetUserData(264711061,"amount");
	var receiverMSISDN = widget.retrieveWidgetUserData(264711061,"msisdn");
	pin = nullorUndefCheck(pin);
	rechargeAmount = nullorUndefCheck(amount);
	receiverMSISDN = validateMSISDN(nullorUndefCheck(receiverMSISDN));
	if("" == receiverMSISDN)
	{
		receiverMSISDN = mobile;
	}
	if("true" == nullorUndefCheck(saveCardCheck))
	{
		widget.logWrite(7,"sendSubsAdhocRechReq saveCardInSide::"+saveCardCheck);
		sendaddCardReq(cardName,cardNum,cvv,expiry,nickName,pin,saveCardCheck);
		
	}else
	{
		var cdrStr = "";
		var postdata = "";
		var txn_status = "";
		var txn_message = "";
		
			
		cardName = nullorUndefCheck(cardName);
		cardNum = nullorUndefCheck(cardNum);
		//var cardNum = nullorUndefCheck(cardno1)+nullorUndefCheck(cardno2)+nullorUndefCheck(cardno3)+nullorUndefCheck(cardno4);
		var EXTREFNUM = Math.floor((Math.random() * 1000000) + 1);
		cvv = nullorUndefCheck(cvv);
		if(expiry.indexOf("/") >-1)
		{
		expiry = expiry.split("/");
	   	expiry = expiry[0] + "/" +  expiry[1].substring(2,4);
		}
		nickName = nullorUndefCheck(nickName);
		
		
		

		/*TYPE=STPRCREQ&IMEI=<IMEI no>&MSISDN=<Initiating Subscriber MSISDN>&PIN=<Subscriber PIN>&	MSISDN2=<Receiver MSISDN>&EXTREFNUM=<Unique Reference number in Retailer App>&AMOUNT=<Amount>&SELECTOR=1&LANGUAGE1=en&LANGUAGE2=en&HOLDERNAME=<Holder Name>&CARDNO=<Card number>&EDATE=<Card�s Expiry date>&CVV=<cvv>*/
		if(SENDENCRYPTREQ)
		{
		 postdata = "TYPE=" + SUBS_ADHOC_RECH_TYPE + "&MSISDN="+ mobile +"&Message="+getEncrypt("IMEI=" + imei + "&PIN=" + pin + "&MSISDN2=" + receiverMSISDN + "&AMOUNT=" + rechargeAmount + "&SELECTOR=" + SELECTOR  + "&HOLDERNAME=" + cardName + "&CARDNO=" + cardNum + "&EDATE=" + expiry + "&CVV=" + cvv+"&EXTREFNUM="+EXTREFNUM+"&LANGUAGE1="+LANGUAGE1 +"&LANGUAGE2="+LANGUAGE2);
		}else
		{
			postdata = "TYPE=" + SUBS_ADHOC_RECH_TYPE + "&MSISDN="+ mobile +"&Message=IMEI=" + imei + "&PIN=" + pin + "&MSISDN2=" + receiverMSISDN + "&AMOUNT=" + rechargeAmount + "&SELECTOR=" + SELECTOR  + "&HOLDERNAME=" + cardName + "&CARDNO=" + cardNum + "&EDATE=" + expiry + "&CVV=" + cvv+"&EXTREFNUM="+EXTREFNUM+"&LANGUAGE1="+LANGUAGE1 +"&LANGUAGE2="+LANGUAGE2;
		}
		widget.logWrite(7,"sendSubsAdhocRechReq postdata request::"+postdata);
		if (null == xmlHttp)
		{
			xmlHttp = new XMLHttpRequest () ;			
		}
		if (xmlHttp)
		{
			xmlHttp.onreadystatechange = function()
			{
				if (4 == xmlHttp.readyState &&  200 == xmlHttp.status)
				{
					//var xmlDoc = xmlHttp.responseXML ;
					var xmlText = xmlHttp.responseText ;
					widget.logWrite(7,"response for sendSubsAdhocRechReq: "+xmlText);
					if (xmlText != null && !xmlText.indexOf("null") > -1 )
					{
						txn_status 	= responseStr(xmlText, STR_TXNSTATUS) ;
						txn_message = responseStr(xmlText, STR_TXNMESSAGE);
						cdrStr +="|"+txn_status+"|"+txn_message+"|"+changetimeformat();
						widget.writeCDR (1, cdrStr) ;
						widget.logWrite(7,"cdrstr logs.."+cdrStr);
						cdrcommon(cdrStr);
						window.location = "wgt:264711061/1.0:payStatus('"+txn_status+"','"+txn_message+"')";
					}else
					 {
						/*divElement= document.getElementById("post1");
						divElement.title = "PreTUPS";
						divElement.innerHTML = STR_SERVER_ERROR;
						divElement.style.display = "block";*/
						window.location = "wgt:264711061/1.0:payStatus('"+txn_status+"','"+STR_SERVER_ERROR+"')";
					 }
				}else
				{
					/*var str;
					var divElement;
					str = STR_SERVICE_ERROR;

					divElement= document.getElementById("post1");
					divElement.title = "PreTUPS";
					divElement.innerHTML = str;
					divElement.style.display = "block";*/
					window.location = "wgt:264711061/1.0:payStatus('"+txn_status+"','"+STR_SERVICE_ERROR+"')";
				}  			

			};
			xmlHttp.open ("POST", url , false) ;
			xmlHttp.setRequestHeader("Content-Type", "plain");
			xmlHttp.setRequestHeader("Connection", "close");
			cdrStr += changetimeformat()+"| Adhoc Recharge ";
			xmlHttp.send (postdata) ;
		}
	}
}

function sendviewCardReq(pin,type){

	
	
		var cdrStr= "";
		var cardDetails = "";
		var postdata = "";
		
		if(PIN_CHECK_ALL == STR_PIN_CHECK && PIN_CHECK_NONFIN == STR_PIN_CHECK && PIN_CHECK_VIEWCARD == STR_PIN_CHECK)
		{
			if("" == nullorUndefCheck(pin))
			{
				pin = widget.retrieveWidgetUserData(251238406,"viewCardPin");
				if("" == nullorUndefCheck(pin))
				{
					pin = widget.retrieveWidgetUserData(264711061,"viewCardPin");
				}
				if("" == nullorUndefCheck(pin))
				{
					pin = widget.retrieveWidgetUserData(950181717,"viewCardPin");
				}
				if("" == nullorUndefCheck(pin))
				{
					pin = widget.retrieveUserData("viewCardPin");
				}
			}	
		}else
		{
			pin = "";
		}
		
		//widget.logWrite(7,"sendviewCardReq  "+pin);
		
		if( "" == nullorUndefCheck(mobile))
		{
			mobile = widget.retrieveWidgetUserData(950181717,"regMSISDN");	
		}
		
		pin = nullorUndefCheck(pin);
					
				
		/*TYPE=STPVCREQ&IMEI=<IMEI no>&MSISDN=<Initiating Subscriber MSISDN>&PIN=<Subscriber PIN>&LANGUAGE1=en*/
		if(SENDENCRYPTREQ)
		{
			postdata = "TYPE=" + VIEWCARDS_TYPE + "&MSISDN=" + mobile + "&Message="+getEncrypt("IMEI=" + imei + "&PIN=" + pin); 
		}else
		{
			 postdata = "TYPE=" + VIEWCARDS_TYPE + "&MSISDN=" + mobile + "&Message=IMEI=" + imei + "&PIN=" + pin;
		}
		widget.logWrite(7,"sendviewCardReqpostdata request ::"+postdata);
		if (null == xmlHttp)
		{
			xmlHttp = new XMLHttpRequest () ;			
		}
		if (xmlHttp)
		{
			xmlHttp.onreadystatechange = function()
			{
				if (4 == xmlHttp.readyState &&  200 == xmlHttp.status)
				{
					//var xmlDoc = xmlHttp.responseXML ;
					var xmlText = xmlHttp.responseText ;
					widget.logWrite(7,"response for sendviewCardReq: "+xmlText );
					if (xmlText != null && !xmlText.indexOf("null") > -1 )
					{
						var txn_status 		= responseStr(xmlText, STR_TXNSTATUS) ;
						var txn_message 	= responseStr(xmlText, STR_TXNMESSAGE) ;
						cardDetails 		= responseStr(xmlText, STR_CARDDETAILS);
						//var cardCount 	= responseStr(xmlText, STR_CARDCOUNT);
						cdrStr +="|"+txn_status+"|"+txn_message+"|"+changetimeformat();
						widget.writeCDR (1, cdrStr) ;
						widget.logWrite(7,"cdrstr logs.."+cdrStr);
						cdrcommon(cdrStr);
						
						if(txn_status == STR_SUCCESS || txn_status ==STR_NOCARD_RES_CODE)	
						{
							if(type == 1 || type == "1")
							{
								if( "" != nullorUndefCheck(pin))
								{
									widget.storeUserData("viewCardPin",pin);
								}
								if("" == nullorUndefCheck(cardDetails))
								{
									window.location = "wgt:251238406/1.0:cards('','"+STR_NOCARD_RES+"')";
								}else
								{
									window.location = "wgt:251238406/1.0:cards('','"+cardDetails+"')";
								}
								
							}else
							{
								return cardDetails;
							}
													
						}else
						{
							if(type == 1 || type == "1")
							{
								document.getElementById("toast").innerHTML = txn_message;
								document.getElementById("toast").style.display="block";
							}else
							{
								return cardDetails;
							}
						}

						return cardDetails;

					}else
					{
						if(type == 1 || type == "1")
						{
							document.getElementById("toast").innerHTML = STR_SERVER_ERROR;
							document.getElementById("toast").style.display="block";
						}else
						{
							return cardDetails;
						}
					}
				}else
				{
					if(type == 1 || type == "1")
					{
						document.getElementById("toast").innerHTML = STR_SERVICE_ERROR;
						document.getElementById("toast").style.display="block";
					}else
					{
						return cardDetails;
					}
				}  				

			};
			xmlHttp.open ("POST", url , false) ;
			xmlHttp.setRequestHeader("Content-Type", "plain");
			xmlHttp.setRequestHeader("Connection", "close");
			cdrStr += changetimeformat()+"| viewCards";
			xmlHttp.send (postdata) ;
		}

		return cardDetails;
}

//view buddy's
function sendviewBuddyReq(pin,type)
{
	
	
	var cdrStr="";
	var buddylist = "";
	var postdata = "";
	if(PIN_CHECK_ALL == STR_PIN_CHECK && PIN_CHECK_NONFIN == STR_PIN_CHECK && PIN_CHECK_VIEWBUDDY == STR_PIN_CHECK)
	{
		if("" == nullorUndefCheck(pin))
		{
			pin = widget.retrieveUserData("viewbuddypin");
		}
		if("" == nullorUndefCheck(pin))
		{
			pin = widget.retrieveWidgetUserData(950181717,"viewbuddypin");
		}
		
	}else
	{
		pin = "";
	}
	
	pin = nullorUndefCheck(pin);
	widget.logWrite(7,"sendviewBuddyReq pin::"+pin);
	if( "" == nullorUndefCheck(mobile))
	{
		mobile = widget.retrieveWidgetUserData(950181717,"regMSISDN");	
	}
	
	/*TYPE=PLISTREQ&IMEI=<IMEI no>&MSISDN=<Initiating Subscriber MSISDN>&PIN=<Subscriber PIN>&LANGUAGE1=en*/
	if(SENDENCRYPTREQ)
	{
		postdata = "TYPE=" + VIEWBUDDY_TYPE + "&MSISDN=" + mobile + "&Message="+getEncrypt("IMEI=" + imei + "&PIN=" + pin + "&LANGUAGE1="+LANGUAGE1);
	}else
	{
		postdata = "TYPE=" + VIEWBUDDY_TYPE + "&MSISDN=" + mobile + "&Message=IMEI=" + imei + "&PIN=" + pin + "&LANGUAGE1="+LANGUAGE1;
	}
	widget.logWrite(7,"sendviewBuddyReq postdata request::"+postdata);
	if (null == xmlHttp)
	{
		xmlHttp = new XMLHttpRequest () ;			
	}
	if (xmlHttp)
	{
		xmlHttp.onreadystatechange = function()
		{
			if (4 == xmlHttp.readyState &&  200 == xmlHttp.status)
			{
				
				var xmlText = xmlHttp.responseText ;
				widget.logWrite(7,"response for sendviewBuddyReq: "+xmlText);
				if (xmlText != null && !xmlText.indexOf("null") > -1 )
				{
					var txn_status 	= responseStr(xmlText, STR_TXNSTATUS) ;
					var txn_message = responseStr(xmlText, STR_TXNMESSAGE) ;
					buddylist =		 responseStr(xmlText,STR_BUDDYLIST);
					cdrStr +="|"+txn_status+"|"+txn_message+"|"+changetimeformat();
					//widget.writeCDR (1, cdrStr) ;
					widget.logWrite(7,"cdrstr logs.."+cdrStr);
					cdrcommon(cdrStr);
										
					if(txn_status == STR_SUCCESS || txn_status == STR_NOBUDDIES)	
					{
						if(type == 1 || type == "1")
						{
							if( "" != nullorUndefCheck(pin))
							{
								widget.storeUserData("viewbuddypin",pin);
						
							}
							if("" == nullorUndefCheck(buddylist))
							{
								window.location = "wgt:264711061/1.0:buddies('','','','"+STR_NOBUDDY_RES+"')";
							}else
							{
								window.location = "wgt:264711061/1.0:buddies('','','','"+buddylist+"')";
							}
						}else
						{
							return buddylist;
						}
													
					}else
					{
						if(type == 1 || type == "1")
						{
							document.getElementById("toast").innerHTML = txn_message;
							document.getElementById("toast").style.display="block";
						}else
						{
							return buddylist;
						}
					}
					return buddylist;
				}else
				 {
					if(type == 1 || type == "1")
					{
						document.getElementById("toast").innerHTML = STR_SERVER_ERROR;
						document.getElementById("toast").style.display="block";
					}else
					{
						return buddylist;
					}
				 }
			}else
			{
				if(type == 1 || type == "1")
				{
					document.getElementById("toast").innerHTML = STR_SERVICE_ERROR;
					document.getElementById("toast").style.display="block";
				}else
				{
					return buddylist;
				}
			}  				

		};
		xmlHttp.open ("POST", url , false) ;
		xmlHttp.setRequestHeader("Content-Type", "plain");
		xmlHttp.setRequestHeader("Connection", "close");
		cdrStr += changetimeformat()+"| viewBuddys ";
		xmlHttp.send (postdata) ;
	}

	return buddylist;
}


function responseStr(respText,strParam)
{

	var respParams;
	var paramValue="";
	if("" != nullorUndefCheck(respText))
	{
		respText = respText.split("&");
		for (var i = 0;i < respText.length; i++)
		{
			respParams = respText[i].split("=");
			if(respParams.length > 1 && respParams[0] == strParam)
			{
				paramValue = respParams[1];
			}
		}
	}
	/*if(paramValue.indexOf(":") > -1)
	{
		paramValue = paramValue.split(":");
		paramValue = paramValue[paramValue.length-1];
	}*/
	
	return paramValue.replace(/\n/g, ' ');

}

function getEncrypt(data)
{
	var encrypt_url = ENCRYPT_URL;
	
	var respText = null;
	var xmlhttp = null;
	var encryptKey = "";
	encryptKey = widget.retrieveUserData("ekey");
	if("" == nullorUndefCheck(encryptKey))
	{
		encryptKey = widget.retrieveWidgetUserData(950181717,"ekey");
	}
	var postdata = encryptKey+"|"+data;
	widget.logWrite(7,"encrypt PostData:"+postdata);
	if (null == xmlhttp)
	{
		xmlhttp = new XMLHttpRequest();
	}
	if (xmlhttp)
	{
		xmlhttp.onreadystatechange = function ()
		{
			widget.logWrite(6, " getEncrypt xmlhttp.readyState =============== > " + xmlhttp.readyState);
			if (xmlhttp.readyState == 4)
			{
				if (200 == xmlhttp.status)
				{
					//widget.storePageData ("mstrack2plg", 1, xmlhttp.responseBytes) ; 
					respText = xmlhttp.responseText;
					widget.logWrite(6, " getEncrypt respText =============== > " + respText);
				}
			}
		};
	}
	xmlhttp.open("POST",encrypt_url, false);
	xmlhttp.send(postdata);
	return respText;
}
