var STR_MOB_NO ="Mobile Number";
var STR_PIN ="PIN";
var STR_AMOUNT="Amount(Rs)";

/*var STR_TXNSTATUS = "TXNSTATUS";
var STR_TXNMESSAGE = "MESSAGE";
var STR_EKEY 	= "ENK"; 
var STR_CARDDETAILS = "CARDDETAILS";
var STR_CARDCOUNT = "REGISTEREDCARDS";*/

var STR_PINCHECK = "PIN and NewPIN InCorrect";
/*var STR_SUCCESS = "200";*/

//SERVER ERROR MESSSAGE PROVIDED BY APP
var STR_SERVER_ERROR 	= "No Response from Server";
var STR_SERVICE_ERROR 	= "Service Unavailable";
var STR_PINCHECK 	= "newPIN and confirmPIN InCorrect";


var STR_PIN_CHECK = true;


/*encrypt url*/

var ENCRYPT_URL = "AES128Plugin:plugin.webaxn.comviva.com?";
var BUDDY_MODIFY = "MODIFY";
var BUDDYMODIFY_MSG = "Your Buddy has been updated";