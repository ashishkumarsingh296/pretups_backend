var STR_ACCOUNT_TITLE = "Account";
var STR_CHANGEPIN_TEXT = "Change Pin";
var STR_OLDPIN_TITLE = "Old Pin"; 
var STR_NEWPIN_TITLE = "New Pin";
var STR_CNEWPIN_TITLE = "Confirm Pin";
var STR_CHANGE_TEXT = "Change";
var STR_PINCHANGECHECK = "Show Pin";
