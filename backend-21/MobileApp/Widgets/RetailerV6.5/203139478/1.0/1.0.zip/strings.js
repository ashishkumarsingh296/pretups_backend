var STR_MOB_NO ="Enter Agent's MSISDN";
var STR_PIN ="PIN";
var STR_AMOUNT="Amount(Rs)";
var STR_MSISDN_TITLE = "Enter MSISDN";
var STR_AMOUNT_TITLE = "Enter Amount";
var STR_PIN_TITLE = "PIN";
