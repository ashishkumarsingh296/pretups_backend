var STR_MOB_NO ="Mobile Number";
var STR_PIN ="PIN";
var STR_AMOUNT="Amount(Rs)";
var STR_PIN_TITLE = "PIN";
var STR_DAILYREPORT = "Daily Reports";
var STR_STOCKBAL 	= "Stock Balance";
var STR_LAST5TRANS =  "Last 5 Transactions";
