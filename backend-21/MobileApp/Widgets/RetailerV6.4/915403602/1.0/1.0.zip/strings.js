var STR_MOB_NO ="Enter Agent's MSISDN";
var STR_PIN ="PIN";
var STR_AMOUNT="Amount(Rs)";
