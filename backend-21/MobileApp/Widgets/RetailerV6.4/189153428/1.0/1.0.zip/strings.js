var STR_MOB_NO ="Mobile Number";
var STR_PIN ="PIN";
var STR_AMOUNT="Amount(Rs)";
var STR_OLDPIN_TITLE = "Enter Old PIN";
var STR_NEWPIN_TITLE = "Enter New PIN";
var STR_CONFIRMPIN_TITLE = "Confirm New PIN";
