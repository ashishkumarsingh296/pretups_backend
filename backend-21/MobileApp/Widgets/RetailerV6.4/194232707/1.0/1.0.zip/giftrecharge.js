var xmlHttp = null ;

var pinNum = widget.retrieveWidgetUserData(179878594,"launchPIN") ;
var mobile = widget.retrieveWidgetUserData(179878594,"launchMSISDN") ;
var imei = widget.retrieveWidgetUserData(179878594, "IMEI");

var PreTUPSSERVER = widget.widgetProperty ("PreTUPSSERVER") ;
var LOGIN = widget.widgetProperty ("LOGIN") ;
var PASSWORD = widget.widgetProperty ("PASSWORD") ;
var REQUEST_GATEWAY_CODE = widget.widgetProperty ("REQUEST_GATEWAY_CODE") ;
var REQUEST_GATEWAY_TYPE = widget.widgetProperty ("REQUEST_GATEWAY_TYPE") ;
var SERVICE_PORT = widget.widgetProperty ("SERVICE_PORT") ;
var SOURCE_TYPE = widget.widgetProperty ("SOURCE_TYPE") ;
var TYPE = widget.widgetProperty ("TYPE") ;
var LOGINID = widget.widgetProperty("LOGINID");
var PASSWORDXML = widget.widgetProperty("PASSWORDXML");
var LANGUAGE1 = widget.widgetProperty("LANGUAGE1");
var LANGUAGE2 = widget.widgetProperty("LANGUAGE2");
var SELECTOR =  widget.widgetProperty("SELECTOR");
var EXTCODE =  widget.widgetProperty("EXTCODE");
var EXTNWCODE =  widget.widgetProperty("EXTNWCODE");
var EXTREFNUM =  widget.widgetProperty("EXTREFNUM");
var GIFTERNAME = widget.widgetProperty("GIFTER_NAME");
var GIFTERLANGUAGE = widget.widgetProperty("GIFTER_LANGUAGE");
var GRECHARGE_TYPE = widget.widgetProperty ("PLAINREQ_TYPE") ;
function sendGiftRechargeReq(payeemobNumber,giftermobNumber,RechargeAmount,Pin)
{
	payeemobNumber 		= nullorUndefCheck(payeemobNumber);
	giftermobNumber 	= nullorUndefCheck(giftermobNumber);
	RechargeAmount 		= nullorUndefCheck(RechargeAmount);
	Pin 				= nullorUndefCheck(Pin);

	if(SENDREQUEST_XML)
	{
		sendGiftRechargeReqXML(payeemobNumber,giftermobNumber,RechargeAmount,Pin);
	}else
	{

		var str="";
		var divElement = "";
		var postData="";
		var url = "";
		var cdrStr = "";
		RechargeAmount = Number(RechargeAmount);
		var k = isNaN(RechargeAmount) ;
		k = k.toString(); 
		widget.logWrite(6,"bearer type:"+bearer);
		widget.logWrite(6,"number value"+RechargeAmount);
		widget.logWrite(6,"number value1"+k);

		if(bearer != SMS_BEARER_TYPE && (payeemobNumber == "" || giftermobNumber == "" || RechargeAmount == "" || Pin==""))
		{
			str="Sorry,field(s) cannot be empty. Please enter valid input";

			divElement = document.getElementById("post2");
			divElement.innerHTML = str ;
			divElement.style.display = "block";
		}else if(bearer != SMS_BEARER_TYPE && (RechargeAmount>11111111 || k=="true"))
		{

			divElement = document.getElementById ("post2");
			divElement.style.display = "block";
			divElement.innerHTML = "Please Enter Valid Amount.";
		}else
		{
			var PreTUPSSERVER = widget.widgetProperty ("PreTUPSSERVER") ;
			var LOGIN = widget.widgetProperty ("LOGIN") ;
			var PASSWORD = widget.widgetProperty ("PASSWORD") ;
			var REQUEST_GATEWAY_CODE = widget.widgetProperty ("REQUEST_GATEWAY_CODE") ;
			var REQUEST_GATEWAY_TYPE = widget.widgetProperty ("REQUEST_GATEWAY_TYPE") ;
			var SERVICE_PORT = widget.widgetProperty ("SERVICE_PORT") ;
			var SOURCE_TYPE = widget.widgetProperty ("SOURCE_TYPE") ;
			
			
			url=PreTUPSSERVER + "?REQUEST_GATEWAY_CODE="+REQUEST_GATEWAY_CODE+"&REQUEST_GATEWAY_TYPE="+REQUEST_GATEWAY_TYPE+"&LOGIN="+LOGIN+"&PASSWORD="+PASSWORD+"&SOURCE_TYPE="+SOURCE_TYPE+"&SERVICE_PORT="+SERVICE_PORT;

			if(DEMO_FLAG == '1' || DEMO_FLAG == 1)
			{
				url= DEMO_URL;
			}

			widget.logWrite(7,"url for sendGiftRechargeReq request::"+url);

			if(SEND_ENCRYPTREQ)
			{

				postData = "TYPE="+GRECHARGE_TYPE+"&MSISDN="+mobile+"&Message="+getEncrypt("IMEI="+imei+"&PIN="+Pin+"&MSISDN2="+giftermobNumber+"&AMOUNT="+RechargeAmount+"&SELECTOR="+SELECTOR);
			}else
			{
				postData = "TYPE="+GRECHARGE_TYPE+"&MSISDN="+mobile+"&Message=IMEI="+imei+"&PIN="+Pin+"&MSISDN2="+giftermobNumber+"&AMOUNT="+RechargeAmount+"&SELECTOR="+SELECTOR;
			}

			widget.logWrite(7," sendGiftRechargeReq ::"+postData);

			if (null == xmlHttp)
			{
				xmlHttp = new XMLHttpRequest () ;	
			}
			if (xmlHttp)
			{

				xmlHttp.onreadystatechange = function()
				{
					if (4 == xmlHttp.readyState &&  200 == xmlHttp.status)
					{

						var xmlText = xmlHttp.responseText ;
						widget.logWrite(7,"response for sendGiftRechargeReq::"+xmlText);
						if (xmlText != null && !xmlText.indexOf("null") > -1)
						{
							var txn_status 	= responseStr(xmlText, STR_TXNSTATUS) ;
							var txn_message = responseStr(xmlText, STR_TXNMESSAGE) ;
							cdrStr +="|"+txn_status+"|"+txn_message+"|"+changetimeformat();

							widget.logWrite(7,"cdrstr logs.."+cdrStr);
							cdrcommon(cdrStr);
							if(txn_status == STR_SUCCESS)
							{
								divElement= document.getElementById("post");
								divElement.title = STR_TITLE;
								divElement.innerHTML = txn_message+"<setvar name=\"payeemobilenu\" value=''/><setvar name=\"Giftermobilenu\" value=''/><setvar name=\"amount\" value=''/><setvar name=\"pin\" value='' />";
								divElement.style.display = "block";

							}else
							{
								divElement= document.getElementById("post");
								divElement.title = STR_TITLE;
								divElement.innerHTML = txn_message+"<setvar name=\"mobilenu\" value=''><setvar name=\"amount\" value=''/><setvar name=\"pin\" value='' />";
								divElement.style.display = "block";
							}
						}else
						{

							str = STR_SERVER_ERROR;
							divElement= document.getElementById("post");
							divElement.title = STR_TITLE;
							divElement.innerHTML = str+"<setvar name=\"mobilenu\" value=''/><setvar name=\"amount\" value=''/><setvar name=\"pin\" value='' />";
							divElement.style.display = "block";
						}
					}else
					{
						str = STR_SERVICE_ERROR;
						divElement= document.getElementById("post");
						divElement.title =STR_TITLE;
						divElement.innerHTML = str+"<setvar name=\"mobilenu\" value=''/><setvar name=\"amount\" value=''/><setvar name=\"pin\" value=''/>";
						divElement.style.display = "block";
					} 

				};

				xmlHttp.open ("POST", url , false) ;
				xmlHttp.setRequestHeader("Content-Type", "plain");
				xmlHttp.setRequestHeader("Connection", "close");
				cdrStr += changetimeformat()+"| Recharge";
				xmlHttp.send (postData) ;


			}

		}

	}
}
function sendGiftRechargeReqXML(payeemobNumber,giftermobNumber,RechargeAmount,Pin)
{
	var str="";
	var divElement;
	RechargeAmount = Number(RechargeAmount);
	var k = isNaN(RechargeAmount) ;
	k = k.toString(); 
	widget.logWrite(6,"number value"+RechargeAmount);
	widget.logWrite(6,"number value1"+k);
	if(payeemobNumber == "" || giftermobNumber == "" || RechargeAmount == "" || Pin=="")
	{
		str="Sorry,field(s) cannot be empty. Please enter valid input";

		divElement = document.getElementById("post2");
		divElement.innerHTML = str ;
		divElement.style.display = "block";
	}
	else if(RechargeAmount>11111111 || k=="true")
	{
		
	var element = document.getElementById ("post2");
	element.style.display = "block";
	
	element.innerHTML = "Please Enter Valid Amount."+"<setvar name=\"mobilenu\" value=''/><setvar name=\"amount\" value=''/><setvar name=\"pin\" value=''/>";
	}
	else
	{
	var date = changetimeformat();
	var url="" + PreTUPSSERVER + "?REQUEST_GATEWAY_CODE="+REQUEST_GATEWAY_CODE+"&REQUEST_GATEWAY_TYPE="+REQUEST_GATEWAY_TYPE+"&LOGIN="+LOGIN+"&PASSWORD="+PASSWORD+"&SOURCE_TYPE="+SOURCE_TYPE+"&SERVICE_PORT="+SERVICE_PORT+"";
	//var xmldata = "<?xml version=\"1.0\"?><COMMAND><TYPE>EXGFTRCREQ</TYPE><DATE>20-08-12 14:12:53</DATE><EXTNWCODE>MO</EXTNWCODE><MSISDN>9867045847</MSISDN><PIN>1357</PIN><LOGINID>Rahul_Choube</LOGINID><PASSWORD>com@1234</PASSWORD><EXTCODE>123</EXTCODE><EXTREFNUM>12345</EXTREFNUM><MSISDN2>9942222</MSISDN2><AMOUNT>50055</AMOUNT><LANGUAGE1>0</LANGUAGE1><LANGUAGE2>0</LANGUAGE2><SELECTOR>1</SELECTOR><GIFTER_MSISDN>9942222</GIFTER_MSISDN><GIFTER_NAME>Chad</GIFTER_NAME><GIFTER_LANGUAGE>0</GIFTER_LANGUAGE></COMMAND>";

	
	/*<COMMAND>
	<TYPE>EXGFTRCREQ</TYPE>
<DATE><Date and time ></DATE>
	<EXTNWCODE><Network External Code></EXTNWCODE>
	<MSISDN><Retailer MSISDN></MSISDN>
	<PIN><123456></PIN>
	<LOGINID><Channel user Login ID></LOGINID>
	<PASSWORD><Channel User Login Password></PASSWORD>
	<EXTCODE><Channel user unique External code></EXTCODE>
 <EXTREFNUM><Unique Reference number in the external system></EXTREFNUM>	
	<MSISDN2>< Payee MSISDN></MSISDN2>
	<AMOUNT><Amount></AMOUNT>   
<LANGUAGE1><Retailer Language></LANGUAGE1>
<LANGUAGE2><Payee Language></LANGUAGE2>
<SELECTOR><Selector></SELECTOR>
<GIFTER_MSISDN><Gifter MSISDN></GIFTER_MSISDN>
<GIFTER_NAME><Gifter NAME></GIFTER_NAME>
<GIFTER_LANGUAGE><Gifter Language></GIFTER_LANGUAGE >
</COMMAND>
*/

	
	var xmldata = [ "<?xml version=\"1.0\"?>",
					"<COMMAND>",
					"<TYPE>" + TYPE + "</TYPE>",
					"<DATE>" + date + "</DATE>",
					"<EXTNWCODE>" + EXTNWCODE + "</EXTNWCODE>",
					"<MSISDN>" + mobile + "</MSISDN>",
					"<PIN>" + pinNum + "</PIN>",
					"<LOGINID>" + LOGINID + "</LOGINID>",
					"<PASSWORD>" + PASSWORDXML + "</PASSWORD>",
					"<EXTCODE>" + EXTCODE + "</EXTCODE>",
					"<EXTREFNUM>" + EXTREFNUM + "</EXTREFNUM>",
					"<MSISDN2>" + payeemobNumber + "</MSISDN2>",
					"<AMOUNT>" + RechargeAmount + "</AMOUNT>",
					"<LANGUAGE1>" + LANGUAGE1 + "</LANGUAGE1>",
					"<LANGUAGE2>" + LANGUAGE2 + "</LANGUAGE2>",
					"<SELECTOR>" + SELECTOR + "</SELECTOR>",
					"<GIFTER_MSISDN>" + giftermobNumber + "</GIFTER_MSISDN>",
					"<GIFTER_NAME>" + GIFTERNAME + "</GIFTER_NAME>",
					"<GIFTER_LANGUAGE>" + GIFTERLANGUAGE + "</GIFTER_LANGUAGE>",
					"</COMMAND>"].join("");
					
					

	/* var xmldata = [ "<?xml version=\"1.0\"?>",
					"<COMMAND>",
					"<TYPE>" + TYPE + "</TYPE>",
					"<DATE>" + date + "</DATE>",
					"<MSISDN1>" + mobNumber + "</MSISDN1>",
					"<PIN>" + Pin + "</PIN>",
					"<MSISDN2>" + payeemobNumber + "</MSISDN2>",
					"<AMOUNT>" + RechargeAmount + "</AMOUNT>",
					"<LANGUAGE1>" + LANGUAGE1 + "</LANGUAGE1>",
					"<LANGUAGE2>" + LANGUAGE2 + "</LANGUAGE2>",
					"<SELECTOR>" + SELECTOR + "</SELECTOR>",
					"<GIFTER_MSISDN>" + giftermobNumber + "</GIFTER_MSISDN>",
					"<GIFTER_NAME>" + GIFTERNAME + "</GIFTER_NAME>",
					"<GIFTER_LANGUAGE>" + GIFTERLANGUAGE + "</GIFTER_LANGUAGE>",
					"</COMMAND>"].join(""); */
	widget.logWrite(7,"xml format request"+xmldata);
	if (null == xmlHttp)
	{
		xmlHttp = new XMLHttpRequest () ;			
	}
	if (xmlHttp)
	{
		xmlHttp.onreadystatechange = giftrechargeReq ;
		xmlHttp.open ("POST", url , false) ;
		xmlHttp.setRequestHeader("Content-Type", "xml");
		xmlHttp.setRequestHeader("Connection", "close");
		xmlHttp.send (xmldata) ;
	}
	
}
}

function giftrechargeReq()
{

	if (4 == xmlHttp.readyState &&  200 == xmlHttp.status)
	{
		var xmlText = xmlHttp.responseText ;
		widget.logWrite(7,"xml response for giftrecharge"+xmlText);
		if (xmlText)
		{
			parsegiftRecharge(xmlText) ;
		}
	}
	else
		{
			var str;
			var divElement;
			str = "Service Unavailable";
			if (bearer == USSD_BEARER_TYPE)
			{
				str += "<a id='back' href='javascript:displayMain();'>1. Back</a>";
			}
			divElement= document.getElementById("post");
			divElement.innerHTML = str+"<setvar name=\"mobilenu\" value=''/><setvar name=\"amount\" value=''/><setvar name=\"pin\" value=''/>";
			divElement.style.display = "block";  
		}
}

function parsegiftRecharge(xmlDoc)
{
	var divElement;
	var str="";
	var tran_Msg;
	if (xmlDoc == null || xmlDoc.indexOf("null") > -1)
	{
		str += "No information from server";
	}
	else
	{
		var rootele = document.createElement ("root") ;
		rootele.innerHTML = xmlDoc ;
		var rechargeInfo = rootele.getElementsByTagName("COMMAND") ;
		var type =  rechargeInfo[0].getElementsByTagName("TYPE")[0].textContent;
		var tran_Status =  rechargeInfo[0].getElementsByTagName("TXNSTATUS")[0].textContent;
		var date =  rechargeInfo[0].getElementsByTagName("DATE")[0].textContent;
		var unque_no =  rechargeInfo[0].getElementsByTagName("EXTREFNUM")[0].textContent;
		var tran_ID =  rechargeInfo[0].getElementsByTagName("TXNID")[0].textContent;
		tran_Msg =  rechargeInfo[0].getElementsByTagName("MESSAGE")[0].textContent;
		if(tran_Msg != null && !tran_Msg.equals("")){
			str += tran_Msg;
		}else{
			if(0 == (tran_Status).indexOf("200")){
				str += "Success"
			}else{
				str += "Error ( "+tran_Status+" )";
			}
		}
	}
	if (bearer == USSD_BEARER_TYPE)
	{
		str += "<a id='back' href='javascript:displayMain();'>1. Back</a>";
	}
	divElement= document.getElementById("post");
	divElement.innerHTML = str+"<setvar name=\"mobilenu\" value=''/><setvar name=\"amount\" value=''/><setvar name=\"pin\" value=''/>";
	divElement.style.display = "block";  
}




