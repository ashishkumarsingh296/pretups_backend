var STR_MOB_NO ="Payee MSISDN";
var STR_GIFT_NO ="Gifter MSISDN";
var STR_PIN ="PIN";
var STR_AMOUNT="Amount(Rs)";
