var xmlHttp = null ;
var USSD_BEARER_TYPE = 2;
var SMS_BEARER_TYPE = 3;
var widget = window.widget ;	
var bearer = widget.fetchBearerType () ;
var welMsg = "Welcome 7200009999";
var flag=false;

var mobile = widget.retrieveWidgetUserData(179878594,"launchMSISDN") ;
var imei = widget.retrieveWidgetUserData(179878594, "IMEI");
var ekey = widget.retrieveWidgetUserData(179878594, "ekey");
//var url = "http://172.16.1.121:1515/selftopup/SelfTopUpReceiver?REQUEST_GATEWAY_CODE=STUGW&REQUEST_GATEWAY_TYPE=STUGW&LOGIN=pretups&PASSWORD=pretups123&SOURCE_TYPE=plain&SERVICE_PORT=190";
url = "http://122.166.59.161:8190/webaxn/plugin?plugin=pretupsDEMOSIMULATOR";
url =  widget.urlEncode(url);
function rechargeMenu()
{
	//href='wgt:179878594/1.0/:displayMain()'
	var formPage="";
	
	
	formPage += "<div id='recharge' class='c3lMenuGroup'>";
	formPage += "<div width='100%' class='c3lMenuGroup topMessage'><span width='85%' align='left' >"+STR_PRETUPS_TITLE+"</span><a style='margin-right:20px' align='right' id= 'home' name='home' href='#Main_Menu' ><img align='right' class='listicon' width='15%' resimg='listicon.png' src='listicon.png'/></a></div><br/>";
	formPage += "<span width='100%' align='left' class='welcomeMsg'>"+STR_RECHARGE+"</span><br/>";
	formPage += "<input type='numeric' id='mobilenu'  emptyok='false' class='inputBG' resimg='inputbg.9.png' align='center' width='80%'  maxlength='15' name='mobilenu' value=''title='"+STR_MSISDN_TITLE+"' maxLength='"+MSISDN_LEN+"'/><setvar name=\"mobilenu\" value=\"\"/>";
	formPage += "<input type='decimal' id='amount'  emptyok='false' align='center' class='inputBG' resimg='inputbg.9.png' name='amount' value=''  width='80%'  title='"+STR_AMOUNT_TITLE+" ' maxLength='"+AMOUNT_LEN+"' /><setvar name=\"amount\" value=\"\"/>";
	formPage += "<input  emptyok='false' class='inputBG' resimg='inputbg.9.png'  align='center'    width='80%'  type='numpassword' maxlength='4' id='pin' name='pin' title='"+STR_PIN_TITLE+"' maxLength='"+PIN_LEN+"' value=''/><setvar name=\"pin\" value=\"\"/><br/>";
	formPage += "<br/>";
	formPage += "<a id='rechBut' class='c3lMenuGroup' type='ajax' href='rechBut()'>.</a>";
	formPage += "</div>" ;
	// main Menu
	var mainPage = displayMain();
	//
	
	
	document.getElementById("Menu_Recharge").innerHTML = formPage;
	document.getElementById("Menu_Recharge").style.display = "block"; 
	document.getElementById("Main_Menu").innerHTML = mainPage  ;
	document.getElementById("Main_Menu").style.display = "block";
	document.getElementById("transfer").style.display = "block";
	document.getElementById("billpay").style.display = "block";
	document.getElementById("returnstock").style.display = "block";
	document.getElementById("reports").style.display = "block";
	document.getElementById("giftRecharge").style.display = "block";
	document.getElementById("elecvocher").style.display = "block";
	document.getElementById("changepin").style.display = "block";
	widget.savePermanent = true;
}

function mainMenu()
{
	var mainPage = displayMain();
	document.getElementById("Main_Menu").innerHTML = mainPage ;
	document.getElementById("Main_Menu").style.display = "block";
	document.getElementById("Menu_Recharge").style.display = "block"; 
	document.getElementById("transfer").style.display = "block";
	document.getElementById("billpay").style.display = "block";
	document.getElementById("returnstock").style.display = "block";
	document.getElementById("reports").style.display = "block";
	document.getElementById("giftRecharge").style.display = "block";
	document.getElementById("elecvocher").style.display = "block";
	document.getElementById("changepin").style.display = "block";
	
}
function rechBut()
{
	widget.logWrite(7,"rechButton page start");
	var str = "";
	str += "<div class='c3lMenuGroup' id='rechBut'>";
	if(BYPASS_WEBAXN)
	{
		str += "<a id='recharge' class='c3lMenuGroup buttonBgBlue1' resimg='buttonnew.png' align='center' href=\"validate://targetid=$mobilenu$;$amount$;$pin$&action=fetchurl://url="+url+"&postdata=$postdata$&ekey="+ekey+"&encryptreq=true\"  althref='sms://inapp?to=+919986027668&text=PRC $mobilenu$:$amount$:$pin$' ><span align='center'  class='buttonText' >Recharge</span></a>" ;
		str +="<setvar name='postdata' value='TYPE=ADHOCRC&MSISDN=7200026159&Message=IMEI="+imei+"&PIN=$pin$&MSISDN2=$mobilenu$&AMOUNT=$amount$&SELECTOR="+SELECTOR+"'/>";
	}else
	{
		str += "<a id='recharge' class='c3lMenuGroup buttonBgBlue1' resimg='buttonnew.png' align='center' href='sendRechargeReq($mobilenu,$amount,$pin);'  althref='sms://inapp?to=+919986027668&text=PRC $mobilenu$:$amount$:$pin$' ><span align='center'  class='buttonText' >Recharge</span></a>" ;
	}
	str +="</div>";
	var divElement= document.getElementById("Menu_Recharge");
	divElement.innerHTML = str;
	divElement.style.display = "block";  
	document.getElementById("transfer").style.display = "block";
	document.getElementById("Menu_Recharge").style.display = "block"; 
	document.getElementById("transfer").style.display = "block";
	document.getElementById("billpay").style.display = "block";
	document.getElementById("returnstock").style.display = "block";
	document.getElementById("reports").style.display = "block";
	document.getElementById("giftRecharge").style.display = "block";
	document.getElementById("elecvocher").style.display = "block";
	document.getElementById("changepin").style.display = "block";
}

function display()
{
	var mainPage = "<div class='c3lMenuGroup'>";
	mainPage += "<span width='100%' align='left' class='topMessage'>PreTUPS</span><br/>";
	mainPage += "<a href=\"#Menu_Recharge\" id=\"recharge\" class =\"c3lMenuGroup options\" width=\"100%\"><img name=\"img\" valign='middle' align=\"left\" resimg='recharge.png' src=\"recharge.png\" /><span class='textalign' valign='middle'>Recharge</span><img name=\"img\" valign='middle' align=\"right\" resimg='rightarr.png' src=\"rightarr.png\" /></a><br/>";
	mainPage += "<a href=\"#changepin\"  class =\"c3lMenuGroup options\" width=\"100%\"><img name=\"img\" valign='middle' align=\"left\" resimg=\"settings.png\" src=\"settings.png\" /><span class='textalign' valign='middle'>Change PIN</span><img name=\"img\" valign='middle' align=\"right\" resimg='rightarr.png' src=\"rightarr.png\" /></a>";
	mainPage += "<a id='displayMainMenu' class='c3lMenuGroup' type='ajax' href='displayMainMenu()'>.</a>";
	mainPage += "</div>";
	//return mainPage;
	document.getElementById("Main_Menu").innerHTML = str ;
	document.getElementById("Main_Menu").style.display = "block";
	
}



function displayMainMenu()
{
	var str = "";
	str += "<div id='displayMainMenu' class='c3lMenuGroup'>"; 
	
	//str += "<span width='100%' align='left' class='topMessage'>PreTUPS</span><br/>";
						
	if(TRANSFER)
	{
	str += "<a href=\"#transfer\"  class =\"c3lMenuGroup options\" width=\"100%\"><img name=\"img\" valign='middle' align=\"left\"  resimg='returnstock.png' src=\"returnstock.png\" /><span class='textalign' valign='middle'>Transfer</span><img name=\"img\" valign='middle' align=\"right\" resimg='rightarr.png' src=\"rightarr.png\" /></a><br/>";
	}
	if(BILLPAYMENT)
	{
	str += "<a href=\"#billpay\"  class =\"c3lMenuGroup options\" width=\"100%\"><img name=\"img\" valign='middle' align=\"lefts\" resimg='billpayment.png' src=\"billpayment.png\" /><span class='textalign' valign='middle'>Bill Payment</span><img name=\"img\" valign='middle' align=\"right\" resimg='rightarr.png' src=\"rightarr.png\" /></a><br/>";
	}
	if(RETURNSTOCK)
	{
	str += "<a href=\"#returnstock\"  class =\"c3lMenuGroup options\" width=\"100%\"><img name=\"img\" valign='middle' align=\"left\" resimg=\"returnstock.png\" src=\"returnstock.png\" /><span class='textalign' valign='middle'>Return Stock</span><img name=\"img\" valign='middle' align=\"right\" resimg='rightarr.png' src=\"rightarr.png\" /></a><br/>";
	}
	if(REPORTS)
	{
	str += "<a href=\"#reports\" class =\"c3lMenuGroup options\" width=\"100%\"><img name=\"img\" valign='middle' align=\"left\" resimg=\"reports.png\" src=\"reports.png\" /><span class='textalign' valign='middle'>Reports</span><img name=\"img\" valign='middle' align=\"right\" resimg='rightarr.png' src=\"rightarr.png\" /></a><br/>";
	}
	if(GIFTRECHARGE)
	{
	str += "<a href=\"#giftRecharge\"  class =\"c3lMenuGroup options\" width=\"100%\"><img name=\"img\" valign='middle' align=\"left\" resimg=\"giftrecharge.png\"  src=\"giftrecharge.png\" /><span class='textalign' valign='middle'>Gift Recharge</span><img name=\"img\" valign='middle' align=\"right\" resimg='rightarr.png' src=\"rightarr.png\" /></a><br/>";
	}
	if(ELECVOUCHER)
	{
	str += "<a href='#elecvocher'  class =\"c3lMenuGroup options\" width=\"100%\"><img name=\"img\" valign='middle' align=\"left\" resimg=\"settings.png\" src=\"settings.png\" /><span class='textalign' valign='middle'>Electronic Voucher</span><img name=\"img\" valign='middle' align=\"right\" resimg='rightarr.png' src=\"rightarr.png\" /></a>";
	
	}
	str += "<a href=\"#changepin\"  class =\"c3lMenuGroup options\" width=\"100%\"><img name=\"img\" valign='middle' align=\"left\" resimg=\"settings.png\" src=\"settings.png\" /><span class='textalign' valign='middle'>Change PIN</span><img name=\"img\" valign='middle' align=\"right\" resimg='rightarr.png' src=\"rightarr.png\" /></a>";
	str +="</div>";
	
	
	document.getElementById("Main_Menu").innerHTML = str ;
	document.getElementById("Main_Menu").style.display = "block";
	
	
}


function elevocreq(mobilenu,amount,pin)
{	
	var msg= "Thank You,You account has been recharged with Rs."+amount+" is Successful";
	widget.logWrite(6,"alertTemp***********************");
	var element = document.getElementById("alert");
	element.style.display = "block";
		element.innerHTML = msg+"<setvar name='mobilenu' value=''/><setvar name='amount' value=''/><setvar name='pin' value='' />";
}

function loadVirtualKeyPad()
{
	var anchorDisplay = new Array() ;
	var str = "";
	anchorDisplay[0] = "<a  width='30%' id='1'  class='c3lMenuGroup vkeypad'  href='keypad://append?name=$pin$&value=1'  style='background-color:white;margin:2px 2px 2px 2px'><span align='center' style='color:black;'>1</span></a>" ;
	anchorDisplay[1] = "<a  width='30%' id='2'  class='c3lMenuGroup vkeypad'  href='keypad://append?name=$pin$&value=2' style='background-color:white;margin:2px 2px 2px 2px'><span align='center' style='color:black;'>2</span></a>" ;
	anchorDisplay[2] = "<a  width='30%' id='3'  class='c3lMenuGroup vkeypad'  href='keypad://append?name=$pin$&value=3' style='background-color:white;margin:2px 2px 2px 2px'><span align='center' style='color:black;'>3</span></a>" ;
	anchorDisplay[3] = "<a  width='30%' id='4'  class='c3lMenuGroup vkeypad'  href='keypad://append?name=$pin$&value=4' style='background-color:white;margin:2px 2px 2px 2px'><span align='center' style='color:black;'>4</span></a>" ;
	anchorDisplay[4] = "<a  width='30%' id='5'  class='c3lMenuGroup vkeypad'  href='keypad://append?name=$pin$&value=5' style='background-color:white;margin:2px 2px 2px 2px'><span align='center' style='color:black;'>5</span></a>" ;
	anchorDisplay[5] = "<a  width='30%' id='6'  class='c3lMenuGroup vkeypad'  href='keypad://append?name=$pin$&value=6' style='background-color:white;margin:2px 2px 2px 2px'><span align='center' style='color:black;'>6</span></a>" ;
	anchorDisplay[6] = "<a  width='30%' id='7'  class='c3lMenuGroup vkeypad'  href='keypad://append?name=$pin$&value=7' style='background-color:white;margin:2px 2px 2px 2px'><span align='center' style='color:black;'>7</span></a>" ;
	anchorDisplay[7] = "<a  width='30%' id='8'  class='c3lMenuGroup vkeypad'  href='keypad://append?name=$pin$&value=8' style='background-color:white;margin:2px 2px 2px 2px'><span align='center' style='color:black;'>8</span></a>" ;
	anchorDisplay[8] = "<a  width='30%' id='9'  class='c3lMenuGroup vkeypad'  href='keypad://append?name=$pin$&value=9' style='background-color:white;margin:2px 2px 2px 2px'><span align='center' style='color:black;'>9</span></a>" ;
	clearBtn = "<a  width='30%' id='clr'  class='c3lMenuGroup vkeypad'  href='keypad://clearall?name=$pin$' style='background-color:white;margin:2px 2px 2px 2px'><span align='center' style='color:black;'>CLR</span></a>" ;
	anchorDisplay[9] = "<a  width='30%' id='10' class='c3lMenuGroup vkeypad'  href='keypad://append?name=$pin$&value=0' style='background-color:white;margin:2px 2px 2px 2px'><span align='center' style='color:black;'>0</span></a>" ;
	deleteBtn = "<a  width='30%' id='del'  class='c3lMenuGroup vkeypad'  href='keypad://clearchar?name=$pin$' style='background-color:white;margin:2px 2px 2px 2px'><span align='center' style='color:black;'>DEL</span></a>" ;
	Recharge = "<a  width='30%' id='del'  class='c3lMenuGroup vkeypad'  href=\"validate://targetid=$mobilenu$;$amount$;$pin$&action=fetchurl://url="+url+"&postdata=$postdata$&ekey="+ekey+"&encryptreq=true\"  althref='sms://inapp?to=+919986027668&text=PRC $mobilenu$:$amount$:$pin$'  style='background-color:white;margin:2px 2px 2px 2px'><span align='center' style='color:black;'>"+STR_RECH_TEXT+"</span></a>";
	//var urlencodedpin = widget.urlEncode("name=$pin$&value="+eKey+"&pinlength=$pinlength$");//$%nsi://"+urlencodedpin+"%,
	str += "<div width='100%' class='c3lMenuGroup topMessage'><span width='85%' align='left' >PreTUPS</span><a style='margin-right:20px' align='right' id= 'home' name='home' href='wgt:179878594/1.0/:displayMain()'><img align='right' resimg='listicon.png' src='listicon.png'/></a></div>";
	str += "<span width='100%' align='left' class='welcomeMsg'>Recharges</span>";
	str += "<input type='numeric'  id='mobilenu' name='mobilenu' align='center'  emptyok='false' resimg='inputbg.9.png'  class='inputBG'     value='' title='"+STR_MSISDN_TITLE+"' maxLength='"+MSISDN_LEN+"'/><setvar name=\"mobilenu\" value=\"\"/>";
	str += "<input type='numeric' id='amount'  emptyok='false' align='center' class='inputBG' resimg='inputbg.9.png' name='amount' value=''   title='"+STR_AMOUNT_TITLE+"' maxLength='"+AMOUNT_LEN+"'/><setvar name=\"amount\" value=\"\"/>";
	str += "<input  emptyok='false' class='inputBG'   align='center'      type='numpassword' id='pin' resimg='inputbg.9.png' name='pin' title='"+STR_PIN_TITLE+"' value='' encrypt='true' maxLength='"+PIN_LEN+"'/><setvar name=\"pin\" value=\"\"/>";

	//str += "<div class='c3lMenuGroup' style='margin : 0% 0% 0% 30%;'><input type='numpassword' id='pin' name='pin' emptyok='false' class='inputBG1' resimg='inputbg.9.png'   tabID='amount'   value=''   title='"+STR_PIN_TITLE+"' encrypt='true'  maxLength='"+PIN_LEN+"'/><input type='decimal'    id='amount' name='amount' emptyok='false' resimg='inputbg.9.png'   class='inputBG1'  value='' title='"+STR_AMOUNT_TITLE+" ' maxLength='"+AMOUNT_LEN+"'/><setvar name=\"amount\" value=\"\"/></div>";
	//str += "</div>";	<div align='center'><a id='recharge' class='c3lMenuGroup buttonBgBlue1' resimg='buttonnew.png' align='center' href=\"validate://targetid=$mobilenu$;$amount$;$pin$&action=fetchurl://url="+url+"&postdata=$postdata$&ekey="+ekey+"&encryptreq=true\"  althref='sms://inapp?to=+919986027668&text=PRC $mobilenu$:$amount$:$pin$' ><span align='center' valign='middle' class='buttonText' >Recharge</span></a></div>				
	str = [str,"<div width='90%'  style='background-color:black' align='center' class='c3lMenuGroup'>"+anchorDisplay[0]+anchorDisplay[1]+anchorDisplay[2]+anchorDisplay[3]+anchorDisplay[4]+anchorDisplay[5]+anchorDisplay[6]+anchorDisplay[7]+anchorDisplay[8]+deleteBtn+anchorDisplay[9]+Recharge+"</div>"].join("");
					
	var divElement = document.getElementById("Menu_Recharge");
	divElement.style.display = "block" ;
	divElement.style.backgroundColor = 'black';
    divElement.innerHTML = "<setvar name='pin' value=''/><setvar name='pinlength' value=''/>"+ str;
	//return str;
}
/*function sendMsg(MSISDN,amount,password)
{
var str="";

	var divElement;
	amount = Number(amount);
	var k = isNaN(amount) ;
	k = k.toString(); 
	widget.logWrite(6,"number value"+amount);
	widget.logWrite(6,"number value1"+k);
	if(MSISDN == "" || amount == "" || password=="")
	{
		str="Sorry,field(s) cannot be empty. Please enter valid input";

		divElement = document.getElementById("post2");
		divElement.innerHTML = str ;
		divElement.style.display = "block";
	}
	else if(amount>11111111 || k=="true")
	{

	var element = document.getElementById ("post2");
	element.style.display = "block";

	element.innerHTML = "Please Enter Valid Amount.";
	}
	else
	{

		var message = MSISDN+" "+amount+" "+password;
		str += "<setvar id='mobile' name='mobile' value='"+MSISDN+"'/><setvar id='message' name='message' value='"+message+"'/>Mobile number is: "+MSISDN;
		str += " Recharge Amount is: "+amount;
		str += " pin is: "+password;

		divElement= document.getElementById("rechargeReq");

		divElement.innerHTML = str;
		divElement.style.display = "block";

	}
}
 */
/* function confirmMsg(MSISDN,amount,password)
{
	var str="";
	var divElement;
	amount = Number(amount);
	var k = isNaN(amount) ;
	k = k.toString(); 
	widget.logWrite(6,"number value"+amount);
	widget.logWrite(6,"number value1"+k);
	widget.storeUserData("MobNo", MSISDN) ;
	widget.storeUserData("Amount", amount) ;
	widget.storeUserData("Password", password) ;
	var flag;
	//flag = isNAN(amount);

	if(MSISDN == "" || amount == "" || password=="")
	{
		str="Sorry,field(s) cannot be empty. Please enter valid input";

		divElement = document.getElementById("post2");
		divElement.innerHTML = str ;
		divElement.style.display = "block";
	}
	else if(amount>11111111 || k=="true")
	{

	var element = document.getElementById ("post2");
	element.style.display = "block";

	element.innerHTML = "Please Enter Valid Amount.";
	}
	else
	{


		str += "Mobile no: "+MSISDN+",";
		str += "Amount: "+amount+"";

		divElement= document.getElementById("rechargeReq");
		divElement.innerHTML = str;
		divElement.style.display = "block";

	}
} */

function sendRechargeReq(mobNumber,RechargeAmount,Pin)
{

	mobNumber 		= nullorUndefCheck(mobNumber);
	RechargeAmount 	= nullorUndefCheck(RechargeAmount);
	Pin 			= nullorUndefCheck(Pin);

	if(SENDREQUEST_XML)
	{
		sendRechargeReqXML(mobNumber,RechargeAmount,Pin);
	}else
	{
		var str="";
		var postData = "";
		var divElement = "";
		var url = "";
		var cdrStr = "";
		RechargeAmount = Number(RechargeAmount);
		var k = isNaN(RechargeAmount) ;
		k = k.toString(); 
		widget.logWrite(6,"bearer type:"+bearer);
		widget.logWrite(6,"number value"+RechargeAmount);
		widget.logWrite(6,"number value1"+k);

		if(bearer != SMS_BEARER_TYPE && (mobNumber == "" || RechargeAmount == "" || Pin==""))
		{
			str="Sorry,field(s) cannot be empty. Please enter valid input";

			divElement = document.getElementById("post2");
			divElement.innerHTML = str ;
			divElement.style.display = "block";
		}else if(bearer != SMS_BEARER_TYPE && (RechargeAmount>11111111 || k=="true"))
		{

			divElement = document.getElementById ("post2");
			divElement.style.display = "block";
			divElement.innerHTML = "Please Enter Valid Amount."+"<setvar name='mobilenu' value=''/><setvar name='amount' value=''/><setvar name='pin' value=''/>";
		}else
		{

			url=PreTUPSSERVER + "?REQUEST_GATEWAY_CODE="+REQUEST_GATEWAY_CODE+"&REQUEST_GATEWAY_TYPE="+REQUEST_GATEWAY_TYPE+"&LOGIN="+LOGIN+"&PASSWORD="+PASSWORD+"&SOURCE_TYPE="+SOURCE_TYPE+"&SERVICE_PORT="+SERVICE_PORT;

			if(DEMO_FLAG == '1' || DEMO_FLAG == 1)
			{
				url= DEMO_URL;
			}

			widget.logWrite(7,"url for recharge request::"+url);
			//widget.logWrite(7,"encrypt request"+"TYPE="+TYPE+"&MSISDN="+mobile+"&Message=IMEI="+imei+"&PIN="+Pin+"&MSISDN2="+mobNumber+"&AMOUNT="+RechargeAmount+"&SELECTOR="+SELECTOR);
			//var postData = "TYPE="+TYPE+"&MSISDN="+mobile+"&Message="+getEncrypt("IMEI="+imei+"&PIN="+Pin+"&MSISDN2="+mobNumber+"&AMOUNT="+RechargeAmount+"&SELECTOR="+SELECTOR);
			if(SEND_ENCRYPTREQ)
			{
				postData = "TYPE="+RECHARGE_TYPE+"&MSISDN="+mobile+"&Message="+getEncrypt("IMEI="+imei+"&PIN="+Pin+"&MSISDN2="+mobNumber+"&AMOUNT="+RechargeAmount+"&SELECTOR="+SELECTOR);
				
			}else
			{
				postData = "TYPE="+RECHARGE_TYPE+"&MSISDN="+mobile+"&Message=IMEI="+imei+"&PIN="+Pin+"&MSISDN2="+mobNumber+"&AMOUNT="+RechargeAmount+"&SELECTOR="+SELECTOR;
			}

			widget.logWrite(7," sendRechargeReq ::"+postData);

			if (null == xmlHttp)
			{
				xmlHttp = new XMLHttpRequest () ;	
			}
			if (xmlHttp)
			{

				xmlHttp.onreadystatechange = function()
				{
					if (4 == xmlHttp.readyState &&  200 == xmlHttp.status)
					{

						var xmlText = xmlHttp.responseText ;
						widget.logWrite(7,"response for rechargeReq::"+xmlText);
						if (xmlText != null && !xmlText.indexOf("null") > -1)
						{
							var txn_status 	= responseStr(xmlText, STR_TXNSTATUS) ;
							var txn_message = responseStr(xmlText, STR_TXNMESSAGE) ;
							cdrStr +="|"+txn_status+"|"+txn_message+"|"+changetimeformat();
							//widget.writeCDR (1, cdrStr) ;
							widget.logWrite(7,"cdrstr logs.."+cdrStr);
							cdrcommon(cdrStr);
							if(txn_status == STR_SUCCESS)
							{
								divElement= document.getElementById("post");
								divElement.title = STR_TITLE;
								divElement.innerHTML = txn_message+"<setvar name='mobilenu' value=''/><setvar name='amount' value=''/><setvar name='pin' value=''/>";
								divElement.style.display = "block";

							}else
							{
								divElement= document.getElementById("post");
								divElement.title = STR_TITLE;
								divElement.innerHTML = txn_message+"<setvar name='mobilenu' value=''/><setvar name='amount' value=''/><setvar name='pin' value=''/>";
								divElement.style.display = "block";
							}
						}else
						{

							str = STR_SERVER_ERROR;
							divElement= document.getElementById("post");
							divElement.title = STR_TITLE;
							divElement.innerHTML = str;
							divElement.style.display = "block";
						}
					}else
					{
						str = STR_SERVICE_ERROR;
						divElement= document.getElementById("post");
						divElement.title =STR_TITLE;
						divElement.innerHTML = str;
						divElement.style.display = "block";
					} 

				};

				xmlHttp.open ("POST", url , false) ;
				xmlHttp.setRequestHeader("Content-Type", "plain");
				xmlHttp.setRequestHeader("Connection", "close");
				cdrStr += changetimeformat()+"| Recharge";
				xmlHttp.send (postData) ;


			}

		}
	}

}

function sendRechargeReqXML(mobNumber,RechargeAmount,Pin)
{
	var str="";
	widget.logWrite(6,"bearer type:"+bearer);
	var divElement;
	RechargeAmount = Number(RechargeAmount);
	var k = isNaN(RechargeAmount) ;
	k = k.toString();
	widget.logWrite(6,"number value"+RechargeAmount);
	widget.logWrite(6,"number value1"+k);
	/* widget.storeUserData("MobNo", MSISDN) ;
        widget.storeUserData("Amount", amount) ;
        widget.storeUserData("Password", password) ; */
	var flag;
	//flag = isNAN(amount);
	if(bearer != SMS_BEARER_TYPE && (mobNumber == "" || RechargeAmount == "" || Pin==""))
	{
		str="Sorry,field(s) cannot be empty. Please enter valid input";

		divElement = document.getElementById("post2");
		divElement.innerHTML = str ;
		divElement.style.display = "block";
	}
	else if(bearer != SMS_BEARER_TYPE && (RechargeAmount>11111111 || k=="true"))
	{

		divElement = document.getElementById ("post2");
		divElement.style.display = "block";
		divElement.innerHTML = "Please Enter Valid Amount."+"<setvar name='mobilenu' value=''/><setvar name='amount' value=''/><setvar name='pin' value=''/>";
	}
	else
	{
		/* var mobNumber = widget.retrieveUserData("MobNo") ;
        var RechargeAmount = widget.retrieveUserData("Amount") ;
        var Pin = widget.retrieveUserData("Password") ; */
		widget.logWrite(6,"mobile no to be retrieved"+mobNumber);

		var PreTUPSSERVER = widget.widgetProperty ("PreTUPSSERVER") ;
		var LOGIN = widget.widgetProperty ("LOGIN") ;
		var PASSWORD = widget.widgetProperty ("PASSWORD") ;
		var REQUEST_GATEWAY_CODE = widget.widgetProperty ("REQUEST_GATEWAY_CODE") ;
		var REQUEST_GATEWAY_TYPE = widget.widgetProperty ("REQUEST_GATEWAY_TYPE") ;
		var SERVICE_PORT = widget.widgetProperty ("SERVICE_PORT") ;
		var SOURCE_TYPE = widget.widgetProperty ("SOURCE_TYPE") ;
		var TYPE = widget.widgetProperty ("TYPE") ;
		var EXTNWCODE = widget.widgetProperty ("EXTNWCODE") ;
		var MSISDN = widget.widgetProperty ("MSISDN") ;
		var PIN = widget.widgetProperty ("PIN") ;
		var EXTCODE = widget.widgetProperty ("EXTCODE") ;
		var EXTTXNNUMBER = widget.widgetProperty ("EXTTXNNUMBER") ;
		var LOGINID = widget.widgetProperty("LOGINID");
		var PASSWORDXML = widget.widgetProperty("PASSWORDXML");
		var MSISDN2 = widget.widgetProperty("MSISDN2");
		var LANGUAGE1 = widget.widgetProperty("LANGUAGE1");
		var LANGUAGE2 = widget.widgetProperty("LANGUAGE2");
		var SELECTOR =  widget.widgetProperty("SELECTOR");


		var date = changetimeformat();
		var url="" + PreTUPSSERVER + "?REQUEST_GATEWAY_CODE="+REQUEST_GATEWAY_CODE+"&REQUEST_GATEWAY_TYPE="+REQUEST_GATEWAY_TYPE+"&LOGIN="+LOGIN+"&PASSWORD="+PASSWORD+"&SOURCE_TYPE="+SOURCE_TYPE+"&SERVICE_PORT="+SERVICE_PORT+"";
		//var xmldata = "<?xml version=\"1.0\"?><!DOCTYPE COMMAND PUBLIC \"-//Ocam//DTD XML Command1.0//EN\" \"xml/command.dtd\"><COMMAND><TYPE>EXRCTRFREQ</TYPE><DATE>25-7-2012 14:36:23</DATE><EXTNWCODE>NG</EXTNWCODE><MSISDN>9867045847</MSISDN><PIN>1357</PIN><LOGINID>Rahul_Choube</LOGINID><PASSWORD>com@1234</PASSWORD><EXTCODE></EXTCODE><EXTREFNUM></EXTREFNUM><MSISDN2>7799000</MSISDN2><AMOUNT>10</AMOUNT><LANGUAGE1>1</LANGUAGE1><LANGUAGE2>1</LANGUAGE2><SELECTOR>1</SELECTOR></COMMAND>";
		widget.logWrite(7,"url for recharge request"+url);
		var xmldata = [ "<?xml version=\"1.0\"?><!DOCTYPE COMMAND PUBLIC \"-//Ocam//DTD XML Command1.0//EN\" \"xml/command.dtd\">" ,
		                "<COMMAND>",
		                "<TYPE>" + TYPE + "</TYPE>",
		                "<DATE>" + date + "</DATE>",
		                "<EXTNWCODE>" + EXTNWCODE + "</EXTNWCODE>",
		                "<MSISDN>" + MSISDN + "</MSISDN>",
		                "<PIN>" + Pin + "</PIN>",
		                "<LOGINID>" + LOGINID + "</LOGINID>",
		                "<PASSWORD>" + PASSWORDXML + "</PASSWORD>",

		                "<EXTCODE></EXTCODE>",
		                "<EXTREFNUM></EXTREFNUM>",
		                "<MSISDN2>" + mobNumber + "</MSISDN2>",
		                "<AMOUNT>" + RechargeAmount + "</AMOUNT>",
		                "<LANGUAGE1>" + LANGUAGE1 + "</LANGUAGE1>",
		                "<LANGUAGE2>" + LANGUAGE2 + "</LANGUAGE2>",
		                "<SELECTOR>1</SELECTOR>",
		                "</COMMAND>"].join("");

		widget.logWrite(7,"xml format request"+xmldata);
		if (null == xmlHttp)
		{
			xmlHttp = new XMLHttpRequest () ;
		}
		if (xmlHttp)
		{
			xmlHttp.onreadystatechange = rechargeReq ;
			xmlHttp.open ("POST", url , false) ;
			xmlHttp.setRequestHeader("Content-Type", "xml");
			xmlHttp.setRequestHeader("Connection", "close");
			xmlHttp.send (xmldata) ;
		}

	}
}

function rechargeReq()
{

	if (4 == xmlHttp.readyState &&  200 == xmlHttp.status)
	{
		widget.logWrite(7,"inside recharge");
		//var xmlDoc = xmlHttp.responseXML ;
		var xmlText = xmlHttp.responseText ;
		widget.logWrite(7,"xml response for recharge"+xmlText);
		if (xmlText)
		{
			parseRecharge(xmlText) ;
		}
	}
	else
	{
		var str;
		var divElement;
		str = "Service Unavailable";
		if(bearer == SMS_BEARER_TYPE){
			/*var senderNo = widget.fetchMSISDNNumber();
                                widget.logWrite(7, "senders number " + senderNo);
                                var sendStatus = widget.sendSMS(senderNo,str,null);//Handle sending SMS to short code with error string received for MSISDN
                                   var sendStatus = widget.sendSMS(senderNo,str,null);//Handle sending SMS to short code with error string received for MSISDN
                                if(sendStatus == 1){
                                        widget.logWrite(6, "SMS sent successfully on Error :"+str);
                                }else{
                                        widget.logWrite(6, "SMS not sent on Error :"+str);
                                }*/
		}else{
			if (bearer == USSD_BEARER_TYPE)
			{
				str += "<a id='back' href='javascript:displayMain();'>1. Back</a>";
			}
			divElement= document.getElementById("post");
			divElement.innerHTML = str+"<setvar name='mobilenu' value=''/><setvar name='amount' value=''/><setvar name='pin' value=''/>";
			divElement.style.display = "block";
		}
	}

}
        function parseRecharge(xmlDoc)
        {
        	var divElement;
        	var str="";
        	var rootele = document.createElement ("root") ;
        	rootele.innerHTML = xmlDoc ;

        	var rechargeInfo = rootele.getElementsByTagName("COMMAND") ;

        	var type =  rechargeInfo[0].getElementsByTagName("TYPE")[0].textContent;
        	var tran_Status =  rechargeInfo[0].getElementsByTagName("TXNSTATUS")[0].textContent;
        	var date =  rechargeInfo[0].getElementsByTagName("DATE")[0].textContent;
        	var unque_no =  rechargeInfo[0].getElementsByTagName("EXTREFNUM")[0].textContent;
        	var tran_ID =  rechargeInfo[0].getElementsByTagName("TXNID")[0].textContent;
        	var tran_Msg =  rechargeInfo[0].getElementsByTagName("MESSAGE")[0].textContent;

        	if(tran_Msg == null || tran_Msg == undefined || tran_Msg == ""){
        		str += "ERROR ("+tran_Status+")";
        	}else{
        		str += tran_Msg;
        	}
        	if(bearer == SMS_BEARER_TYPE){
        		var senderNo = widget.fetchMSISDNNumber();
        		widget.logWrite(7, "senders number " + senderNo);
        		var sendStatus = widget.sendSMS(senderNo,str,null);//Handle sending SMS to short code with string received for MSISDN - Lavanya
        		if(sendStatus == 1){
        			widget.logWrite(6, "SMS sent successfully on Recharge Status :"+str);
        		}else{
        			widget.logWrite(6, "SMS not sent on Recharge status :"+str);
        		}
        	}else{
        		if (bearer == USSD_BEARER_TYPE)
        		{
        			str += "<a id='back' href='javascript:displayMain();'>1. Back</a>";
        		}
        		divElement= document.getElementById("post");
        		divElement.innerHTML = str+"<setvar name='mobilenu' value=''/><setvar name='amount' value=''/><setvar name='pin' value=''/>";
        		divElement.style.display = "block";
        	}
        }
                      

