function toggleTest()
{

	var str = "";
	str +="<div align='center'><span style='margin-bottom:20px'>Test Toggle</span></div>";
	str +="<div id='toggle' align='center' style='display:none'>Hello Toggle Test</div>";
	str +="<input id='but' type='button' value='show/hide' onclick='c3ltoggle:toggle'></input>";
	document.getElementById("Menu_Recharge").innerHTML = str;
	document.getElementById("Menu_Recharge").style.display = "block";
	
}